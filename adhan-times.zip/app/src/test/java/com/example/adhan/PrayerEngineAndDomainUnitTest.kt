package com.example.adhan

import com.example.adhan.data.local.LanguageResolver
import com.example.adhan.data.location.TurkishCitiesCatalog
import com.example.adhan.domain.calculation.DiyanetAstronomicalCalculator
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.CalculationParameters
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.usecase.ComputeNextPrayerUseCase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

class PrayerEngineAndDomainUnitTest {

    private val calculator = DiyanetAstronomicalCalculator()
    private val computeNextPrayer = ComputeNextPrayerUseCase()

    private val istanbul = LocationInfo(
        latitude = 41.0082,
        longitude = 28.9784,
        city = "İstanbul",
        district = "Fatih",
        source = LocationSource.MANUAL,
    )

    private val ankara = LocationInfo(
        latitude = 39.9334,
        longitude = 32.8597,
        city = "Ankara",
        district = "Çankaya",
        source = LocationSource.MANUAL,
    )

    @Test
    fun `prayer times are strictly chronological for Istanbul across seasons`() {
        val zone = ZoneId.of("Europe/Istanbul")
        val dates = listOf(
            LocalDate.of(2026, 1, 15),
            LocalDate.of(2026, 6, 21),
            LocalDate.of(2026, 9, 23),
        )

        for (date in dates) {
            val times = calculator.calculate(date, istanbul, zone)
            assertEquals(6, times.entries.size)
            for (i in 0 until times.entries.size - 1) {
                assertTrue(
                    "Expected ${times.entries[i].prayer} < ${times.entries[i + 1].prayer} on $date",
                    times.entries[i].instant.isBefore(times.entries[i + 1].instant),
                )
            }
            // Istanbul solar noon should sit around 12:30 - 13:45 TRT (UTC+3)
            val dhuhr = times.entryFor(PrayerName.DHUHR).time
            assertTrue("Dhuhr hour out of range: $dhuhr", dhuhr.hour in 12..13)
            assertFalse(times.parameters.isOfficialDiyanetData)
        }
    }

    @Test
    fun `hanafi asr is strictly later than standard shafii asr`() {
        val zone = ZoneId.of("Europe/Istanbul")
        val date = LocalDate.of(2026, 5, 10)
        val standard = calculator.calculate(
            date,
            ankara,
            zone,
            CalculationParameters(asrMadhhab = AsrMadhhab.STANDARD),
        )
        val hanafi = calculator.calculate(
            date,
            ankara,
            zone,
            CalculationParameters(asrMadhhab = AsrMadhhab.HANAFI),
        )
        assertTrue(
            hanafi.entryFor(PrayerName.ASR).instant.isAfter(standard.entryFor(PrayerName.ASR).instant),
        )
    }

    @Test
    fun `high latitude fallback avoids NaN and preserves valid order`() {
        val oslo = LocationInfo(59.9139, 10.7522, "Oslo", "", LocationSource.GPS)
        val times = calculator.calculate(
            LocalDate.of(2026, 6, 21),
            oslo,
            ZoneId.of("Europe/Oslo"),
        )
        for (i in 0 until times.entries.size - 1) {
            assertTrue(times.entries[i].instant.isBefore(times.entries[i + 1].instant))
        }
    }

    @Test
    fun `next prayer selects upcoming prayer and rolls over to tomorrow imsak after isha`() {
        val zone = ZoneId.of("Europe/Istanbul")
        val today = LocalDate.of(2026, 4, 15)
        val todayTimes = calculator.calculate(today, istanbul, zone)
        val tomorrowTimes = calculator.calculate(today.plusDays(1), istanbul, zone)

        // Mid-day between Dhuhr and Asr -> next should be Asr
        val afterDhuhr = todayTimes.entryFor(PrayerName.DHUHR).instant.plusSeconds(120)
        val midDayNext = computeNextPrayer(afterDhuhr, todayTimes, tomorrowTimes)
        assertEquals(PrayerName.ASR, midDayNext.nextPrayer.prayer)
        assertFalse(midDayNext.isTomorrow)
        assertTrue(midDayNext.remainingMillis > 0L)

        // After Isha before midnight -> next should be tomorrow's Imsak with positive remaining time
        val afterIsha = todayTimes.entryFor(PrayerName.ISHA).instant.plusSeconds(600)
        val nightNext = computeNextPrayer(afterIsha, todayTimes, tomorrowTimes)
        assertEquals(PrayerName.IMSAK, nightNext.nextPrayer.prayer)
        assertTrue(nightNext.isTomorrow)
        assertTrue(nightNext.remainingMillis > 0L)
    }

    @Test
    fun `default user preferences keep adhan audio strictly disabled`() {
        val defaults = UserPreferences()
        assertFalse(defaults.enableAdhanAudio)
        assertTrue(defaults.notificationsEnabled)
        assertEquals(2, defaults.stage2DelayMinutes)
        assertEquals(5, defaults.stage3DelayMinutes)
    }

    @Test
    fun `language resolver defaults unsupported locales to turkish`() {
        assertEquals("tr", LanguageResolver.resolveLocale(AppLanguage.SYSTEM, Locale.forLanguageTag("de")).language)
        assertEquals("tr", LanguageResolver.resolveLocale(AppLanguage.SYSTEM, Locale.forLanguageTag("fr")).language)
        assertEquals("tr", LanguageResolver.resolveLocale(AppLanguage.SYSTEM, Locale.forLanguageTag("tr")).language)
        assertEquals("en", LanguageResolver.resolveLocale(AppLanguage.SYSTEM, Locale.forLanguageTag("en")).language)
        assertEquals("en", LanguageResolver.resolveLocale(AppLanguage.EN, Locale.forLanguageTag("tr")).language)
        assertEquals("tr", LanguageResolver.resolveLocale(AppLanguage.TR, Locale.forLanguageTag("en")).language)
    }

    @Test
    fun `turkish cities catalog contains all 81 provinces and supports turkish search`() {
        assertEquals(81, TurkishCitiesCatalog.cities.size)
        assertTrue(TurkishCitiesCatalog.search("istanbul").any { it.plateCode == 34 })
        assertTrue(TurkishCitiesCatalog.search("sanliurfa").any { it.plateCode == 63 })
        assertTrue(TurkishCitiesCatalog.search("06").any { it.name == "Ankara" })
    }
}
