package com.example.adhan

import android.content.Context
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.ActivityResultRegistryOwner
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.core.app.ActivityOptionsCompat
import androidx.test.core.app.ApplicationProvider
import com.example.adhan.data.location.TurkishCitiesCatalog
import com.example.adhan.domain.calculation.DiyanetAstronomicalCalculator
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.usecase.ComputeNextPrayerUseCase
import com.example.adhan.notification.LocalizedContextProvider
import com.example.adhan.presentation.home.HomeScreen
import com.example.adhan.presentation.home.HomeUiState
import com.example.adhan.presentation.home.PrayerRowStatus
import com.example.adhan.presentation.home.PrayerScheduleRow
import com.example.adhan.presentation.location.LocationScreen
import com.example.adhan.presentation.location.LocationUiState
import com.example.adhan.presentation.settings.SettingsScreen
import com.example.adhan.presentation.settings.SettingsUiState
import com.example.adhan.presentation.theme.AdhanTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalDate
import java.time.ZoneId

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w412dp-h915dp")
class AdhanUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private val testActivityResultRegistryOwner = object : ActivityResultRegistryOwner {
        override val activityResultRegistry: ActivityResultRegistry = object : ActivityResultRegistry() {
            override fun <I, O> onLaunch(
                requestCode: Int,
                contract: ActivityResultContract<I, O>,
                input: I,
                options: ActivityOptionsCompat?,
            ) {
                // No-op in isolated UI test
            }
        }
    }

    @Test
    fun `home screen renders location, countdown card, and all 6 prayer rows`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val locCtx = LocalizedContextProvider.localizedContext(context, AppLanguage.TR)
        val location = LocationInfo(41.0082, 28.9784, "İstanbul", "Fatih", LocationSource.MANUAL)
        val zone = ZoneId.of("Europe/Istanbul")
        val calc = DiyanetAstronomicalCalculator()
        val today = calc.calculate(LocalDate.of(2026, 5, 1), location, zone)
        val tomorrow = calc.calculate(LocalDate.of(2026, 5, 2), location, zone)
        val next = ComputeNextPrayerUseCase().invoke(
            today.entries[2].instant.plusSeconds(60),
            today,
            tomorrow,
        )
        val rows = today.entries.map {
            PrayerScheduleRow(
                prayer = it.prayer,
                formattedTime = String.format("%02d:%02d", it.time.hour, it.time.minute),
                status = if (it.prayer == next.nextPrayer.prayer) PrayerRowStatus.NEXT else PrayerRowStatus.UPCOMING,
            )
        }

        composeTestRule.setContent {
            CompositionLocalProvider(
                LocalContext provides locCtx,
                LocalActivityResultRegistryOwner provides testActivityResultRegistryOwner,
            ) {
                AdhanTheme {
                    HomeScreen(
                        uiState = HomeUiState(
                            isLoading = false,
                            location = location,
                            todayTimes = today,
                            tomorrowTimes = tomorrow,
                            nextPrayerState = next,
                            rows = rows,
                            appLanguage = AppLanguage.TR,
                            hasLocationPermission = true,
                        ),
                        onRefreshLocation = {},
                        onNavigateToLocation = {},
                        onStopAdhan = {},
                        onPermissionsUpdated = {},
                        onDismissStatusMessage = {},
                    )
                }
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("home_location_chip").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_countdown_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_countdown_timer").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_prayer_list").performScrollToNode(hasTestTag("prayer_row_IMSAK"))
        composeTestRule.onNodeWithTag("prayer_row_IMSAK").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_prayer_list").performScrollToNode(hasTestTag("prayer_row_ISHA"))
        composeTestRule.onNodeWithTag("prayer_row_ISHA").assertIsDisplayed()
    }

    @Test
    fun `settings screen shows audio switch off by default and switches language live`() {
        val baseContext = ApplicationProvider.getApplicationContext<Context>()
        var prefs by mutableStateOf(UserPreferences())

        composeTestRule.setContent {
            val locCtx = LocalizedContextProvider.localizedContext(baseContext, prefs.appLanguage)
            CompositionLocalProvider(
                LocalContext provides locCtx,
                LocalActivityResultRegistryOwner provides testActivityResultRegistryOwner,
            ) {
                AdhanTheme {
                    SettingsScreen(
                        uiState = SettingsUiState(preferences = prefs),
                        onLanguageChange = { prefs = prefs.copy(appLanguage = it) },
                        onThemeChange = {},
                        onAdhanAudioToggle = { prefs = prefs.copy(enableAdhanAudio = it) },
                        onNotificationsToggle = {},
                        onStageDelaysChange = { _, _ -> },
                        onAsrMadhhabChange = {},
                        onSendTestNotification = {},
                        onRefreshLocation = {},
                        onNavigateToLocation = {},
                        onStopAdhan = {},
                        onPermissionsUpdated = {},
                        onClearSnackbar = {},
                    )
                }
            }
        }

        composeTestRule.waitForIdle()
        // Audio switch MUST start OFF by default
        composeTestRule.onNodeWithTag("settings_list").performScrollToNode(hasTestTag("settings_adhan_audio_switch"))
        composeTestRule.onNodeWithTag("settings_adhan_audio_switch").assertIsOff()
        composeTestRule.onNodeWithTag("settings_adhan_audio_switch").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("settings_adhan_audio_switch").assertIsOn()

        // Switch language to English and verify UI updates immediately without restart
        composeTestRule.onNodeWithTag("settings_list").performScrollToNode(hasTestTag("settings_language_en"))
        composeTestRule.onNodeWithTag("settings_language_en").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Settings").assertIsDisplayed()

        // Switch back to Turkish
        composeTestRule.onNodeWithTag("settings_language_tr").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Ayarlar").assertIsDisplayed()
    }

    @Test
    fun `location screen searches turkish cities and selects district`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val locCtx = LocalizedContextProvider.localizedContext(context, AppLanguage.TR)
        var uiState by mutableStateOf(
            LocationUiState(
                filteredCities = TurkishCitiesCatalog.cities,
                hasLocationPermission = false,
                permissionDeniedExplicitly = true,
            ),
        )
        var selectedDistrictName: String? = null

        composeTestRule.setContent {
            CompositionLocalProvider(
                LocalContext provides locCtx,
                LocalActivityResultRegistryOwner provides testActivityResultRegistryOwner,
            ) {
                AdhanTheme {
                    LocationScreen(
                        uiState = uiState,
                        onSearchQueryChanged = { query ->
                            uiState = uiState.copy(
                                searchQuery = query,
                                filteredCities = TurkishCitiesCatalog.search(query),
                            )
                        },
                        onCityClicked = { city ->
                            uiState = uiState.copy(expandedCityPlateCode = city.plateCode)
                        },
                        onDistrictSelected = { _, district ->
                            selectedDistrictName = district.name
                        },
                        onDetectGps = {},
                        onPermissionResult = {},
                        onClearFeedback = {},
                    )
                }
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("location_search_input").performScrollTo()
        composeTestRule.onNodeWithTag("location_search_input").performTextInput("Ankara")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("city_item_6").performScrollTo()
        composeTestRule.onNodeWithTag("city_item_6").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("district_chip_6_Çankaya").performScrollTo()
        composeTestRule.onNodeWithTag("district_chip_6_Çankaya").performClick()
        composeTestRule.waitForIdle()
        assertEquals("Çankaya", selectedDistrictName)
    }
}
