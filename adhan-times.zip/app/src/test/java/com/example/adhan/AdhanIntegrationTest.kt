package com.example.adhan

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Looper
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.test.core.app.ApplicationProvider
import com.example.adhan.data.local.AlarmDeliveryGuard
import com.example.adhan.data.local.DataStoreSettingsRepository
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.NotificationStage
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.domain.model.ThemeMode
import com.example.adhan.notification.NotificationHelper
import com.example.adhan.receiver.AlarmReceiver
import com.example.adhan.service.AdhanAudioService
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AdhanIntegrationTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun `datastore persists language, theme, location, and keeps adhan audio false by default`() = runTest {
        val dataStore = PreferenceDataStoreFactory.create(
            produceFile = { File(tempFolder.newFolder(), "test_prefs.preferences_pb") },
        )
        val repo = DataStoreSettingsRepository(dataStore)

        val initial = repo.getCurrentPreferences()
        assertFalse(initial.enableAdhanAudio)
        assertNull(initial.savedLocation)

        repo.setLanguage(AppLanguage.EN)
        repo.setThemeMode(ThemeMode.DARK)
        repo.setEnableAdhanAudio(true)
        repo.saveLocation(
            LocationInfo(39.9334, 32.8597, "Ankara", "Çankaya", LocationSource.MANUAL),
        )

        val updated = repo.getCurrentPreferences()
        assertEquals(AppLanguage.EN, updated.appLanguage)
        assertEquals(ThemeMode.DARK, updated.themeMode)
        assertTrue(updated.enableAdhanAudio)
        assertEquals("Ankara", updated.savedLocation?.city)
        assertEquals("Çankaya", updated.savedLocation?.district)
    }

    @Test
    fun `notification helper creates channels, posts 3 stages in TR and EN, and sends safe test notification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val helper = NotificationHelper(context)
        val app = Shadows.shadowOf(context as android.app.Application)
        app.grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)

        helper.ensureChannels(AppLanguage.TR)
        val nm = context.getSystemService(NotificationManager::class.java)
        assertNotNull(nm.getNotificationChannel(NotificationHelper.CHANNEL_PRAYER_ALERTS))
        assertNotNull(nm.getNotificationChannel(NotificationHelper.CHANNEL_AUDIO_PLAYBACK))

        helper.showPrayerStageNotification(
            prayer = PrayerName.DHUHR,
            stage = NotificationStage.START,
            language = AppLanguage.TR,
            includeStopAdhanAction = false,
        )
        helper.showPrayerStageNotification(
            prayer = PrayerName.DHUHR,
            stage = NotificationStage.ONGOING,
            language = AppLanguage.EN,
            includeStopAdhanAction = false,
        )
        helper.showPrayerStageNotification(
            prayer = PrayerName.DHUHR,
            stage = NotificationStage.END,
            language = AppLanguage.TR,
            includeStopAdhanAction = false,
        )
        assertTrue(helper.sendTestNotification(AppLanguage.EN))

        val shadowNm = Shadows.shadowOf(nm)
        assertEquals(4, shadowNm.allNotifications.size)
        // Test notification must never start AdhanAudioService
        assertNull(Shadows.shadowOf(context).nextStartedService)
    }

    @Test
    fun `alarm scheduler schedules upcoming stages and cancels cleanly`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val app = context.applicationContext as AdhanApplication
        val scheduler = app.appContainer.alarmScheduler

        val fixedMorning = LocalDate.of(2026, 6, 1)
            .atTime(9, 0)
            .atZone(ZoneId.of("Europe/Istanbul"))
            .toInstant()

        scheduler.rescheduleAll(now = fixedMorning, zoneId = ZoneId.of("Europe/Istanbul"))

        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val shadowAlarmManager = Shadows.shadowOf(alarmManager)
        assertTrue(shadowAlarmManager.scheduledAlarms.isNotEmpty())

        scheduler.cancelAllAlarms()
        assertTrue(shadowAlarmManager.scheduledAlarms.isEmpty())
    }

    @Test
    fun `alarm delivery guard blocks duplicate triggers for same event`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val guard = AlarmDeliveryGuard(context)
        guard.clearAll()

        assertTrue(guard.markAndCheckShouldDeliver("2026-06-01_DHUHR_START"))
        assertFalse(guard.markAndCheckShouldDeliver("2026-06-01_DHUHR_START"))
        assertTrue(guard.markAndCheckShouldDeliver("2026-06-01_DHUHR_ONGOING"))
    }

    @Test
    fun `alarm receiver never starts adhan audio when enableAdhanAudio is false`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val app = context.applicationContext as AdhanApplication
        app.appContainer.alarmDeliveryGuard.clearAll()

        val receiver = AlarmReceiver()
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_PRAYER_ALARM
            putExtra(AlarmReceiver.EXTRA_PRAYER_INDEX, PrayerName.ASR.index)
            putExtra(AlarmReceiver.EXTRA_STAGE_INDEX, NotificationStage.START.index)
            putExtra(AlarmReceiver.EXTRA_DATE_ISO, "2026-06-01")
        }

        receiver.onReceive(context, intent)
        Thread.sleep(200)
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        val startedService = Shadows.shadowOf(app).nextStartedService
        assertNull(startedService)
    }

    @Test
    fun `adhan audio service handles stop command cleanly without crashing`() {
        val controller = Robolectric.buildService(AdhanAudioService::class.java).create()
        val service = controller.get()
        val stopIntent = Intent(service, AdhanAudioService::class.java).apply {
            action = AdhanAudioService.ACTION_STOP_ADHAN
        }
        service.onStartCommand(stopIntent, 0, 1)
        controller.destroy()
    }
}
