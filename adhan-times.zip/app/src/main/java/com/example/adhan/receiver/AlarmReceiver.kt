package com.example.adhan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.adhan.AdhanApplication
import com.example.adhan.domain.model.NotificationStage
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.service.AdhanPlaybackController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_PRAYER_ALARM = "com.example.adhan.action.PRAYER_ALARM"
        const val EXTRA_PRAYER_INDEX = "extra_prayer_index"
        const val EXTRA_STAGE_INDEX = "extra_stage_index"
        const val EXTRA_DATE_ISO = "extra_date_iso"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_PRAYER_ALARM) return

        val prayerIndex = intent.getIntExtra(EXTRA_PRAYER_INDEX, -1)
        val stageIndex = intent.getIntExtra(EXTRA_STAGE_INDEX, -1)
        val dateIso = intent.getStringExtra(EXTRA_DATE_ISO).orEmpty()

        val prayer = PrayerName.fromIndex(prayerIndex) ?: return
        val stage = NotificationStage.fromIndex(stageIndex) ?: return

        val app = context.applicationContext as? AdhanApplication ?: return
        val container = app.appContainer

        // Prevent duplicate notifications or audio triggers for the same prayer event
        val eventKey = "${dateIso}_${prayer.name}_${stage.name}"
        if (!container.alarmDeliveryGuard.markAndCheckShouldDeliver(eventKey)) {
            return
        }

        val pendingResult: PendingResult? = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = container.settingsRepository.getCurrentPreferences()
                val shouldPlayAudio = stage == NotificationStage.START &&
                    prefs.enableAdhanAudio &&
                    prayer.supportsAdhanAudio

                if (prefs.notificationsEnabled) {
                    container.notificationHelper.showPrayerStageNotification(
                        prayer = prayer,
                        stage = stage,
                        language = prefs.appLanguage,
                        includeStopAdhanAction = shouldPlayAudio,
                    )
                }

                if (shouldPlayAudio) {
                    AdhanPlaybackController.startAdhan(context.applicationContext, prayer)
                }

                // Keep tomorrow's schedule fresh after Isha starts
                if (prayer == PrayerName.ISHA && stage == NotificationStage.START) {
                    container.alarmScheduler.rescheduleAll()
                }
            } finally {
                pendingResult?.finish()
            }
        }
    }
}
