package com.example.adhan.service

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.example.R
import com.example.adhan.AdhanApplication
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.notification.LocalizedContextProvider
import com.example.adhan.notification.NotificationHelper
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class AdhanAudioService : MediaSessionService() {

    companion object {
        const val ACTION_PLAY_ADHAN = "com.example.adhan.action.PLAY_ADHAN"
        const val ACTION_STOP_ADHAN = "com.example.adhan.action.STOP_ADHAN"
        const val EXTRA_PRAYER_INDEX = "extra_prayer_index"
        private const val CUSTOM_CMD_STOP = "com.example.adhan.session.STOP"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var currentPrayer: PrayerName = PrayerName.DHUHR
    private var currentLanguage: AppLanguage = AppLanguage.SYSTEM

    private lateinit var notificationHelper: NotificationHelper

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
                AdhanPlaybackController.updatePlaybackState(false, null)
                if (playbackState == Player.STATE_ENDED) {
                    stopPlaybackAndService()
                }
            } else if (playbackState == Player.STATE_READY && player?.isPlaying == true) {
                AdhanPlaybackController.updatePlaybackState(true, currentPrayer)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            AdhanPlaybackController.updatePlaybackState(isPlaying, if (isPlaying) currentPrayer else null)
        }

        override fun onPlayerError(error: PlaybackException) {
            notificationHelper.showAudioMissingFallbackNotification(currentLanguage)
            stopPlaybackAndService()
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationHelper = NotificationHelper(this)
        notificationHelper.ensureChannels()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val exoPlayer = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(false)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also { it.addListener(playerListener) }

        player = exoPlayer

        val stopCommand = SessionCommand(CUSTOM_CMD_STOP, Bundle.EMPTY)
        val sessionCallback = object : MediaSession.Callback {
            override fun onConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
            ): MediaSession.ConnectionResult {
                val sessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                    .buildUpon()
                    .add(stopCommand)
                    .build()
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(sessionCommands)
                    .build()
            }

            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                customCommand: SessionCommand,
                args: Bundle,
            ): ListenableFuture<SessionResult> {
                if (customCommand.customAction == CUSTOM_CMD_STOP) {
                    stopPlaybackAndService()
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                return super.onCustomCommand(session, controller, customCommand, args)
            }
        }

        val sessionActivityPendingIntent: PendingIntent = notificationHelper.createLaunchAppIntent()

        mediaSession = MediaSession.Builder(this, exoPlayer)
            .setCallback(sessionCallback)
            .setSessionActivity(sessionActivityPendingIntent)
            .setCustomLayout(
                ImmutableList.of(
                    CommandButton.Builder(CommandButton.ICON_STOP)
                        .setDisplayName(getString(R.string.notif_action_stop_adhan))
                        .setSessionCommand(stopCommand)
                        .build(),
                ),
            )
            .build()

        setMediaNotificationProvider(object : MediaNotification.Provider {
            override fun createNotification(
                mediaSession: MediaSession,
                customLayout: ImmutableList<CommandButton>,
                actionFactory: MediaNotification.ActionFactory,
                onNotificationChangedCallback: MediaNotification.Provider.Callback,
            ): MediaNotification {
                val notification = notificationHelper.buildAudioPlaybackNotification(
                    prayer = currentPrayer,
                    language = currentLanguage,
                )
                return MediaNotification(NotificationHelper.NOTIFICATION_ID_AUDIO_FOREGROUND, notification)
            }

            override fun handleCustomCommand(
                session: MediaSession,
                action: String,
                extras: Bundle,
            ): Boolean {
                if (action == CUSTOM_CMD_STOP) {
                    stopPlaybackAndService()
                    return true
                }
                return false
            }
        })
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP_ADHAN -> {
                stopPlaybackAndService()
                return START_NOT_STICKY
            }
            ACTION_PLAY_ADHAN -> {
                val prayerIdx = intent.getIntExtra(EXTRA_PRAYER_INDEX, PrayerName.DHUHR.index)
                val prayer = PrayerName.fromIndex(prayerIdx) ?: PrayerName.DHUHR
                currentPrayer = prayer

                // Immediately satisfy startForeground contract on Android 8+ / 14+
                startForeground(
                    NotificationHelper.NOTIFICATION_ID_AUDIO_FOREGROUND,
                    notificationHelper.buildAudioPlaybackNotification(prayer, currentLanguage),
                )

                serviceScope.launch {
                    val container = (applicationContext as? AdhanApplication)?.appContainer
                    val prefs = runCatching { container?.settingsRepository?.getCurrentPreferences() }.getOrNull()
                    if (prefs != null && !prefs.enableAdhanAudio) {
                        // Safety rule: never play audio if user preference is false
                        stopPlaybackAndService()
                        return@launch
                    }
                    if (prefs != null) {
                        currentLanguage = prefs.appLanguage
                    }
                    playAdhanResource(prayer)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun playAdhanResource(prayer: PrayerName) {
        val rawResId = resources.getIdentifier("adhan", "raw", packageName)
        if (rawResId == 0) {
            notificationHelper.showAudioMissingFallbackNotification(currentLanguage)
            stopPlaybackAndService()
            return
        }

        val uri: Uri = Uri.parse("android.resource://$packageName/$rawResId")
        val locCtx = LocalizedContextProvider.localizedContext(this, currentLanguage)
        val prayerLabel = locCtx.getString(LocalizedContextProvider.prayerNameRes(prayer))

        val metadata = MediaMetadata.Builder()
            .setTitle(locCtx.getString(R.string.notif_audio_playing_title, prayerLabel))
            .setArtist(locCtx.getString(R.string.app_name))
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()

        val exo = player ?: run {
            stopPlaybackAndService()
            return
        }

        // Prevent simultaneous playback or duplicated streams
        exo.stop()
        exo.clearMediaItems()
        exo.setMediaItem(mediaItem)
        exo.prepare()
        exo.play()
        AdhanPlaybackController.updatePlaybackState(true, prayer)
    }

    private fun stopPlaybackAndService() {
        AdhanPlaybackController.updatePlaybackState(false, null)
        player?.run {
            stop()
            clearMediaItems()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        AdhanPlaybackController.updatePlaybackState(false, null)
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        player = null
        super.onDestroy()
    }
}
