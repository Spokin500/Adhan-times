package com.example.adhan.presentation.location

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.TurkishCity
import com.example.adhan.domain.model.TurkishDistrict
import com.example.adhan.domain.repository.LocationDetectionResult
import com.example.adhan.domain.repository.LocationRepository
import com.example.adhan.domain.repository.SettingsRepository
import com.example.adhan.service.AlarmScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LocationUiState(
    val activeLocation: LocationInfo? = null,
    val searchQuery: String = "",
    val filteredCities: List<TurkishCity> = emptyList(),
    val expandedCityPlateCode: Int? = null,
    val hasLocationPermission: Boolean = false,
    val permissionDeniedExplicitly: Boolean = false,
    val isDetectingGps: Boolean = false,
    val infoMessageResId: Int? = null,
    val savedCityFeedback: String? = null,
)

class LocationViewModel(
    private val settingsRepository: SettingsRepository,
    private val locationRepository: LocationRepository,
    private val alarmScheduler: AlarmScheduler,
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        LocationUiState(
            filteredCities = locationRepository.getAllTurkishCities(),
            hasLocationPermission = locationRepository.hasLocationPermission(),
        ),
    )
    val uiState: StateFlow<LocationUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.preferencesFlow.collectLatest { prefs ->
                _uiState.update {
                    it.copy(
                        activeLocation = prefs.savedLocation ?: locationRepository.defaultFallbackLocation(),
                        hasLocationPermission = locationRepository.hasLocationPermission(),
                    )
                }
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update {
            it.copy(
                searchQuery = query,
                filteredCities = locationRepository.searchTurkishCities(query),
            )
        }
    }

    fun onCityClicked(city: TurkishCity) {
        _uiState.update {
            val newExpanded = if (it.expandedCityPlateCode == city.plateCode) null else city.plateCode
            it.copy(expandedCityPlateCode = newExpanded)
        }
    }

    fun onDistrictSelected(city: TurkishCity, district: TurkishDistrict) {
        viewModelScope.launch {
            val location = LocationInfo(
                latitude = district.latitude,
                longitude = district.longitude,
                city = city.name,
                district = district.name,
                source = LocationSource.MANUAL,
                updatedAtEpochMs = System.currentTimeMillis(),
            )
            settingsRepository.saveLocation(location)
            alarmScheduler.rescheduleAll()
            _uiState.update {
                it.copy(
                    activeLocation = location,
                    expandedCityPlateCode = null,
                    savedCityFeedback = location.displayTitle,
                    infoMessageResId = null,
                )
            }
        }
    }

    fun onPermissionResult(granted: Boolean) {
        _uiState.update {
            it.copy(
                hasLocationPermission = granted,
                permissionDeniedExplicitly = !granted,
            )
        }
        if (granted) {
            detectGpsLocation()
        }
    }

    fun detectGpsLocation() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(isDetectingGps = true, infoMessageResId = null, savedCityFeedback = null)
            }
            when (val result = locationRepository.detectCurrentLocation()) {
                is LocationDetectionResult.Success -> {
                    settingsRepository.saveLocation(result.location)
                    alarmScheduler.rescheduleAll()
                    _uiState.update {
                        it.copy(
                            isDetectingGps = false,
                            hasLocationPermission = true,
                            permissionDeniedExplicitly = false,
                            activeLocation = result.location,
                            savedCityFeedback = result.location.displayTitle,
                            infoMessageResId = if (result.usedGeocoderFallback) {
                                com.example.R.string.location_geocoder_fallback
                            } else {
                                null
                            },
                        )
                    }
                }
                LocationDetectionResult.PermissionMissing -> {
                    _uiState.update {
                        it.copy(
                            isDetectingGps = false,
                            hasLocationPermission = false,
                            permissionDeniedExplicitly = true,
                        )
                    }
                }
                LocationDetectionResult.Unavailable -> {
                    _uiState.update {
                        it.copy(
                            isDetectingGps = false,
                            infoMessageResId = com.example.R.string.location_error_unavailable,
                        )
                    }
                }
            }
        }
    }

    fun clearFeedback() {
        _uiState.update { it.copy(savedCityFeedback = null, infoMessageResId = null) }
    }
}
