package com.example.adhan.presentation.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.adhan.data.local.LanguageResolver
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.ThemeMode

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: SettingsUiState,
    onLanguageChange: (AppLanguage) -> Unit,
    onThemeChange: (ThemeMode) -> Unit,
    onAdhanAudioToggle: (Boolean) -> Unit,
    onNotificationsToggle: (Boolean) -> Unit,
    onStageDelaysChange: (Int, Int) -> Unit,
    onAsrMadhhabChange: (AsrMadhhab) -> Unit,
    onSendTestNotification: () -> Unit,
    onRefreshLocation: () -> Unit,
    onNavigateToLocation: () -> Unit,
    onStopAdhan: () -> Unit,
    onPermissionsUpdated: () -> Unit,
    onClearSnackbar: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val snackbarMsgId = uiState.snackbarMessageResId
    val snackbarText = snackbarMsgId?.let { stringResource(it) }
    LaunchedEffect(snackbarMsgId) {
        if (snackbarText != null) {
            snackbarHostState.showSnackbar(snackbarText)
            onClearSnackbar()
        }
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        onPermissionsUpdated()
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text(stringResource(R.string.settings_privacy_policy_title)) },
            text = { Text(stringResource(R.string.settings_privacy_policy_summary)) },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(stringResource(R.string.settings_close))
                }
            },
        )
    }

    val resolvedLocale = LanguageResolver.resolveLocale(uiState.preferences.appLanguage)
    val isTurkishSelected = resolvedLocale.language == "tr"

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp)
                    .align(Alignment.TopCenter)
                    .testTag("settings_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }

                // 1. Language & Theme
                item {
                    SettingsSectionCard(
                        title = stringResource(R.string.settings_section_appearance),
                        icon = Icons.Rounded.Language,
                    ) {
                        Text(
                            text = stringResource(R.string.settings_language_label),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = isTurkishSelected,
                                onClick = { onLanguageChange(AppLanguage.TR) },
                                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_language_tr"),
                            ) {
                                Text(stringResource(R.string.settings_language_tr))
                            }
                            SegmentedButton(
                                selected = !isTurkishSelected,
                                onClick = { onLanguageChange(AppLanguage.EN) },
                                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_language_en"),
                            ) {
                                Text(stringResource(R.string.settings_language_en))
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DarkMode,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                text = stringResource(R.string.settings_theme_label),
                                style = MaterialTheme.typography.titleMedium,
                            )
                        }

                        val themes = listOf(
                            ThemeMode.SYSTEM to R.string.settings_theme_system,
                            ThemeMode.LIGHT to R.string.settings_theme_light,
                            ThemeMode.DARK to R.string.settings_theme_dark,
                        )
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            themes.forEachIndexed { index, (mode, labelRes) ->
                                SegmentedButton(
                                    selected = uiState.preferences.themeMode == mode,
                                    onClick = { onThemeChange(mode) },
                                    shape = SegmentedButtonDefaults.itemShape(
                                        index = index,
                                        count = themes.size,
                                    ),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("settings_theme_${mode.key}"),
                                ) {
                                    Text(stringResource(labelRes), maxLines = 1)
                                }
                            }
                        }
                    }
                }

                // 2. Adhan Audio (Default strictly OFF)
                item {
                    SettingsSectionCard(
                        title = stringResource(R.string.settings_section_adhan_audio),
                        icon = Icons.AutoMirrored.Rounded.VolumeUp,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(
                                    text = stringResource(R.string.settings_adhan_audio_title),
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Text(
                                    text = stringResource(R.string.settings_adhan_audio_subtitle),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = uiState.preferences.enableAdhanAudio,
                                onCheckedChange = onAdhanAudioToggle,
                                modifier = Modifier.testTag("settings_adhan_audio_switch"),
                            )
                        }

                        if (uiState.isAdhanPlaying) {
                            Button(
                                onClick = onStopAdhan,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError,
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_stop_audio_button"),
                            ) {
                                Icon(Icons.Rounded.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.settings_stop_active_audio))
                            }
                        }
                    }
                }

                // 3. Notifications & Test Button
                item {
                    SettingsSectionCard(
                        title = stringResource(R.string.settings_section_notifications),
                        icon = Icons.Rounded.NotificationsActive,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(
                                    text = stringResource(R.string.settings_notifications_enable_title),
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Text(
                                    text = stringResource(R.string.settings_notifications_enable_subtitle),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = uiState.preferences.notificationsEnabled,
                                onCheckedChange = onNotificationsToggle,
                                modifier = Modifier.testTag("settings_notifications_switch"),
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Text(
                            text = stringResource(R.string.settings_stage2_delay_title),
                            style = MaterialTheme.typography.labelLarge,
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1, 2, 3, 4).forEach { min ->
                                val selected = uiState.preferences.stage2DelayMinutes == min
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        val s3 = uiState.preferences.stage3DelayMinutes.coerceAtLeast(min + 1)
                                        onStageDelaysChange(min, s3)
                                    },
                                    label = { Text(stringResource(R.string.settings_minutes_after, min)) },
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.settings_stage3_delay_title),
                            style = MaterialTheme.typography.labelLarge,
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(3, 5, 7, 10).forEach { min ->
                                val validMin = min.coerceAtLeast(uiState.preferences.stage2DelayMinutes + 1)
                                val selected = uiState.preferences.stage3DelayMinutes == min
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        onStageDelaysChange(uiState.preferences.stage2DelayMinutes, validMin)
                                    },
                                    label = { Text(stringResource(R.string.settings_minutes_after, min)) },
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                )
                            }
                        }

                        if (!uiState.hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            OutlinedButton(
                                onClick = {
                                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize(),
                            ) {
                                Text(stringResource(R.string.home_enable_notifications))
                            }
                        }

                        if (!uiState.canScheduleExactAlarms && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    runCatching { context.startActivity(intent) }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize(),
                            ) {
                                Icon(Icons.Rounded.Alarm, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.home_enable_exact_alarm))
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Text(
                            text = stringResource(R.string.settings_test_notification_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedButton(
                            onClick = onSendTestNotification,
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("settings_test_notification_button"),
                        ) {
                            Icon(Icons.Rounded.NotificationsActive, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.settings_test_notification_button))
                        }
                    }
                }

                // 4. Calculation & Location
                item {
                    SettingsSectionCard(
                        title = stringResource(R.string.settings_section_calculation),
                        icon = Icons.Rounded.LocationOn,
                    ) {
                        Text(
                            text = stringResource(R.string.settings_asr_madhhab_title),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = uiState.preferences.asrMadhhab == AsrMadhhab.STANDARD,
                                onClick = { onAsrMadhhabChange(AsrMadhhab.STANDARD) },
                                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text(stringResource(R.string.settings_asr_standard), maxLines = 1)
                            }
                            SegmentedButton(
                                selected = uiState.preferences.asrMadhhab == AsrMadhhab.HANAFI,
                                onClick = { onAsrMadhhabChange(AsrMadhhab.HANAFI) },
                                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text(stringResource(R.string.settings_asr_hanafi), maxLines = 1)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Text(
                            text = stringResource(R.string.settings_current_location_label),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = uiState.activeLocation?.displayTitle ?: "—",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            OutlinedButton(
                                onClick = onRefreshLocation,
                                enabled = !uiState.isRefreshingLocation,
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize(),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.MyLocation,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.settings_refresh_gps))
                            }
                            Button(
                                onClick = onNavigateToLocation,
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize(),
                            ) {
                                Text(stringResource(R.string.settings_manual_city))
                            }
                        }
                    }
                }

                // 5. App Info & Accuracy Transparency
                item {
                    SettingsSectionCard(
                        title = stringResource(R.string.settings_section_about),
                        icon = Icons.Rounded.Info,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = stringResource(R.string.settings_version_label),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            Text(
                                text = BuildConfig.VERSION_NAME,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Text(
                            text = stringResource(R.string.settings_calculation_note_title),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = stringResource(R.string.settings_calculation_note_body),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )

                        OutlinedButton(
                            onClick = { showPrivacyDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("settings_privacy_button"),
                        ) {
                            Icon(Icons.Rounded.PrivacyTip, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.settings_privacy_policy_title))
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit,
) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            content()
        }
    }
}
