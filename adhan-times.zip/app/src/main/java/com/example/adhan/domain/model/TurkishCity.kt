package com.example.adhan.domain.model

data class TurkishDistrict(
    val name: String,
    val latitude: Double,
    val longitude: Double,
)

data class TurkishCity(
    val plateCode: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val districts: List<TurkishDistrict>,
)
