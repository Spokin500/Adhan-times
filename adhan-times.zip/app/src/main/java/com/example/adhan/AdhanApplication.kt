package com.example.adhan

import android.app.Application
import com.example.adhan.di.AdhanAppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AdhanApplication : Application() {

    lateinit var appContainer: AdhanAppContainer
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appContainer = AdhanAppContainer(this)
        applicationScope.launch {
            val prefs = runCatching {
                appContainer.settingsRepository.getCurrentPreferences()
            }.getOrNull()
            if (prefs != null) {
                appContainer.notificationHelper.ensureChannels(prefs.appLanguage)
                appContainer.alarmScheduler.rescheduleAll()
            } else {
                appContainer.notificationHelper.ensureChannels()
            }
        }
    }
}
