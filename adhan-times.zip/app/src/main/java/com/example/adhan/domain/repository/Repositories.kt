package com.example.adhan.domain.repository

import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.ThemeMode
import com.example.adhan.domain.model.TurkishCity
import com.example.adhan.domain.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.ZoneId

interface SettingsRepository {
    val preferencesFlow: Flow<UserPreferences>

    suspend fun getCurrentPreferences(): UserPreferences
    suspend fun setLanguage(language: AppLanguage)
    suspend fun setThemeMode(themeMode: ThemeMode)
    suspend fun setEnableAdhanAudio(enabled: Boolean)
    suspend fun setNotificationsEnabled(enabled: Boolean)
    suspend fun setAsrMadhhab(madhhab: AsrMadhhab)
    suspend fun setStageDelays(stage2Minutes: Int, stage3Minutes: Int)
    suspend fun saveLocation(location: LocationInfo)
}

interface PrayerTimesRepository {
    fun getPrayerTimes(
        date: LocalDate,
        location: LocationInfo,
        zoneId: ZoneId,
        asrMadhhab: AsrMadhhab,
    ): DailyPrayerTimes
}

sealed interface LocationDetectionResult {
    data class Success(val location: LocationInfo, val usedGeocoderFallback: Boolean = false) : LocationDetectionResult
    data object PermissionMissing : LocationDetectionResult
    data object Unavailable : LocationDetectionResult
}

interface LocationRepository {
    fun hasLocationPermission(): Boolean
    suspend fun detectCurrentLocation(): LocationDetectionResult
    fun getAllTurkishCities(): List<TurkishCity>
    fun searchTurkishCities(query: String): List<TurkishCity>
    fun defaultFallbackLocation(): LocationInfo
}
