package com.example.adhan.domain.model

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

enum class LocationSource {
    GPS,
    MANUAL,
    DEFAULT,
}

data class LocationInfo(
    val latitude: Double,
    val longitude: Double,
    val city: String,
    val district: String,
    val source: LocationSource,
    val updatedAtEpochMs: Long = System.currentTimeMillis(),
) {
    val displayTitle: String
        get() = if (district.isNotBlank() && !district.equals(city, ignoreCase = true)) {
            "$city, $district"
        } else {
            city
        }
}

data class PrayerTimeEntry(
    val prayer: PrayerName,
    val time: ZonedDateTime,
) {
    val instant: Instant get() = time.toInstant()
}

data class CalculationParameters(
    val methodName: String = "DIYANET_ALIGNED_ASTRONOMICAL",
    val fajrAngleDegrees: Double = 18.0,
    val ishaAngleDegrees: Double = 17.0,
    val sunriseDepressionDegrees: Double = 0.8333,
    val asrMadhhab: AsrMadhhab = AsrMadhhab.STANDARD,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.ANGLE_BASED,
    val isOfficialDiyanetData: Boolean = false,
)

data class DailyPrayerTimes(
    val date: LocalDate,
    val zoneId: ZoneId,
    val location: LocationInfo,
    val entries: List<PrayerTimeEntry>,
    val parameters: CalculationParameters,
    val hijriDay: Int,
    val hijriMonth: Int,
    val hijriYear: Int,
) {
    fun entryFor(prayer: PrayerName): PrayerTimeEntry =
        entries.first { it.prayer == prayer }
}

data class NextPrayerState(
    val nextPrayer: PrayerTimeEntry,
    val previousPrayer: PrayerTimeEntry?,
    val remainingMillis: Long,
    val progressFraction: Float,
    val isTomorrow: Boolean,
)

enum class AppLanguage(val tag: String) {
    SYSTEM("system"),
    TR("tr"),
    EN("en");

    companion object {
        fun fromTag(tag: String?): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: SYSTEM
    }
}

enum class ThemeMode(val key: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromKey(key: String?): ThemeMode =
            entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

data class UserPreferences(
    val appLanguage: AppLanguage = AppLanguage.SYSTEM,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val enableAdhanAudio: Boolean = false, // MUST strictly default to false
    val notificationsEnabled: Boolean = true,
    val asrMadhhab: AsrMadhhab = AsrMadhhab.STANDARD,
    val stage2DelayMinutes: Int = 2,
    val stage3DelayMinutes: Int = 5,
    val savedLocation: LocationInfo? = null,
)
