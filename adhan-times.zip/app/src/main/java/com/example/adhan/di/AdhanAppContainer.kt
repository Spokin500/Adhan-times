package com.example.adhan.di

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.adhan.data.local.AlarmDeliveryGuard
import com.example.adhan.data.local.DataStoreSettingsRepository
import com.example.adhan.data.local.adhanPreferencesDataStore
import com.example.adhan.data.location.LocationRepositoryImpl
import com.example.adhan.data.prayer.PrayerTimesRepositoryImpl
import com.example.adhan.domain.calculation.DiyanetAstronomicalCalculator
import com.example.adhan.domain.calculation.PrayerCalculationEngine
import com.example.adhan.domain.repository.LocationRepository
import com.example.adhan.domain.repository.PrayerTimesRepository
import com.example.adhan.domain.repository.SettingsRepository
import com.example.adhan.domain.usecase.ComputeNextPrayerUseCase
import com.example.adhan.domain.usecase.GetDailyPrayerTimesUseCase
import com.example.adhan.notification.NotificationHelper
import com.example.adhan.presentation.home.HomeViewModel
import com.example.adhan.presentation.location.LocationViewModel
import com.example.adhan.presentation.settings.SettingsViewModel
import com.example.adhan.service.AlarmScheduler

class AdhanAppContainer(context: Context) {
    private val appContext = context.applicationContext

    val settingsRepository: SettingsRepository = DataStoreSettingsRepository(
        dataStore = appContext.adhanPreferencesDataStore,
    )

    val alarmDeliveryGuard: AlarmDeliveryGuard = AlarmDeliveryGuard(appContext)

    val prayerCalculationEngine: PrayerCalculationEngine = DiyanetAstronomicalCalculator()

    val prayerTimesRepository: PrayerTimesRepository = PrayerTimesRepositoryImpl(
        calculationEngine = prayerCalculationEngine,
    )

    val locationRepository: LocationRepository = LocationRepositoryImpl(
        context = appContext,
    )

    val notificationHelper: NotificationHelper = NotificationHelper(
        context = appContext,
    )

    val alarmScheduler: AlarmScheduler = AlarmScheduler(
        context = appContext,
        settingsRepository = settingsRepository,
        prayerTimesRepository = prayerTimesRepository,
        locationRepository = locationRepository,
    )

    val getDailyPrayerTimesUseCase: GetDailyPrayerTimesUseCase =
        GetDailyPrayerTimesUseCase(prayerTimesRepository)

    val computeNextPrayerUseCase: ComputeNextPrayerUseCase =
        ComputeNextPrayerUseCase()

    val viewModelFactory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return when {
                modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(
                    appContext = appContext,
                    settingsRepository = settingsRepository,
                    locationRepository = locationRepository,
                    getDailyPrayerTimesUseCase = getDailyPrayerTimesUseCase,
                    computeNextPrayerUseCase = computeNextPrayerUseCase,
                    alarmScheduler = alarmScheduler,
                    notificationHelper = notificationHelper,
                ) as T

                modelClass.isAssignableFrom(LocationViewModel::class.java) -> LocationViewModel(
                    settingsRepository = settingsRepository,
                    locationRepository = locationRepository,
                    alarmScheduler = alarmScheduler,
                ) as T

                modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(
                    appContext = appContext,
                    settingsRepository = settingsRepository,
                    locationRepository = locationRepository,
                    alarmScheduler = alarmScheduler,
                    notificationHelper = notificationHelper,
                ) as T

                else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        }
    }
}
