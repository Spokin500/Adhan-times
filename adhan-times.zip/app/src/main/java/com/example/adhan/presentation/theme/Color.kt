package com.example.adhan.presentation.theme

import androidx.compose.ui.graphics.Color

// Ottoman Emerald & Warm Amber Gold Palette
val EmeraldDeep = Color(0xFF0B2E26)
val EmeraldPrimary = Color(0xFF0F4C3E)
val EmeraldContainer = Color(0xFFD0EBE2)
val OnEmeraldContainer = Color(0xFF04211A)

val GoldAccent = Color(0xFFC48A28)
val GoldBright = Color(0xFFE6B85C)
val GoldContainer = Color(0xFFFAEBCC)
val OnGoldContainer = Color(0xFF3A2400)

val IvorySurface = Color(0xFFFAF7F0)
val IvorySurfaceVariant = Color(0xFFEDE8DC)
val InkPrimary = Color(0xFF131D1A)
val InkMuted = Color(0xFF53635E)

// Dark Theme Tokens
val NightEmeraldBg = Color(0xFF071612)
val NightEmeraldSurface = Color(0xFF0E231D)
val NightEmeraldCard = Color(0xFF153129)
val NightEmeraldPrimary = Color(0xFF6CD3B4)
val NightOnPrimary = Color(0xFF02291E)
val NightEmeraldContainer = Color(0xFF164A3D)
val NightOnContainer = Color(0xFFC9F2E3)
val NightTextPrimary = Color(0xFFF1EFE8)
val NightTextMuted = Color(0xFFA2B5AE)
