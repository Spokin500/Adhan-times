package com.example.adhan.presentation.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.ThemeMode
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.repository.LocationDetectionResult
import com.example.adhan.domain.repository.LocationRepository
import com.example.adhan.domain.repository.SettingsRepository
import com.example.adhan.notification.NotificationHelper
import com.example.adhan.service.AdhanPlaybackController
import com.example.adhan.service.AlarmScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val preferences: UserPreferences = UserPreferences(),
    val activeLocation: LocationInfo? = null,
    val hasNotificationPermission: Boolean = true,
    val canScheduleExactAlarms: Boolean = true,
    val isAdhanPlaying: Boolean = false,
    val isRefreshingLocation: Boolean = false,
    val snackbarMessageResId: Int? = null,
)

class SettingsViewModel(
    private val appContext: Context,
    private val settingsRepository: SettingsRepository,
    private val locationRepository: LocationRepository,
    private val alarmScheduler: AlarmScheduler,
    private val notificationHelper: NotificationHelper,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.preferencesFlow.collectLatest { prefs ->
                _uiState.update {
                    it.copy(
                        preferences = prefs,
                        activeLocation = prefs.savedLocation ?: locationRepository.defaultFallbackLocation(),
                        hasNotificationPermission = notificationHelper.hasNotificationPermission(),
                        canScheduleExactAlarms = alarmScheduler.canScheduleExactAlarms(),
                    )
                }
            }
        }
        viewModelScope.launch {
            AdhanPlaybackController.isPlaying.collectLatest { playing ->
                _uiState.update { it.copy(isAdhanPlaying = playing) }
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsRepository.setLanguage(language)
            notificationHelper.ensureChannels(language)
        }
    }

    fun setThemeMode(themeMode: ThemeMode) {
        viewModelScope.launch {
            settingsRepository.setThemeMode(themeMode)
        }
    }

    fun setEnableAdhanAudio(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setEnableAdhanAudio(enabled)
            if (!enabled) {
                AdhanPlaybackController.stopAdhan(appContext)
            }
            alarmScheduler.rescheduleAll()
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setNotificationsEnabled(enabled)
            alarmScheduler.rescheduleAll()
        }
    }

    fun setAsrMadhhab(madhhab: AsrMadhhab) {
        viewModelScope.launch {
            settingsRepository.setAsrMadhhab(madhhab)
            alarmScheduler.rescheduleAll()
        }
    }

    fun setStageDelays(stage2Minutes: Int, stage3Minutes: Int) {
        viewModelScope.launch {
            settingsRepository.setStageDelays(stage2Minutes, stage3Minutes)
            alarmScheduler.rescheduleAll()
        }
    }

    fun sendTestNotification() {
        val hasPerm = notificationHelper.hasNotificationPermission()
        _uiState.update { it.copy(hasNotificationPermission = hasPerm) }
        if (!hasPerm) {
            _uiState.update {
                it.copy(snackbarMessageResId = com.example.R.string.settings_notification_perm_needed)
            }
            return
        }
        // Strictly sends only a preview notification; NEVER starts Adhan audio
        val sent = notificationHelper.sendTestNotification(_uiState.value.preferences.appLanguage)
        _uiState.update {
            it.copy(
                snackbarMessageResId = if (sent) {
                    com.example.R.string.settings_test_notification_sent
                } else {
                    com.example.R.string.settings_notification_perm_needed
                },
            )
        }
    }

    fun refreshLocation() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingLocation = true) }
            when (val result = locationRepository.detectCurrentLocation()) {
                is LocationDetectionResult.Success -> {
                    settingsRepository.saveLocation(result.location)
                    alarmScheduler.rescheduleAll()
                    _uiState.update {
                        it.copy(
                            isRefreshingLocation = false,
                            snackbarMessageResId = if (result.usedGeocoderFallback) {
                                com.example.R.string.location_geocoder_fallback
                            } else {
                                null
                            },
                        )
                    }
                }
                else -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingLocation = false,
                            snackbarMessageResId = com.example.R.string.location_error_unavailable,
                        )
                    }
                }
            }
        }
    }

    fun stopAdhanAudio() {
        AdhanPlaybackController.stopAdhan(appContext)
    }

    fun refreshPermissions() {
        _uiState.update {
            it.copy(
                hasNotificationPermission = notificationHelper.hasNotificationPermission(),
                canScheduleExactAlarms = alarmScheduler.canScheduleExactAlarms(),
            )
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessageResId = null) }
    }
}
