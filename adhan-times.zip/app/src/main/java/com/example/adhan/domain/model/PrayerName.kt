package com.example.adhan.domain.model

import com.example.adhan.domain.model.PrayerName.ASR
import com.example.adhan.domain.model.PrayerName.DHUHR
import com.example.adhan.domain.model.PrayerName.IMSAK
import com.example.adhan.domain.model.PrayerName.ISHA
import com.example.adhan.domain.model.PrayerName.MAGHRIB
import com.example.adhan.domain.model.PrayerName.SUNRISE

enum class PrayerName(
    val index: Int,
    val supportsAdhanAudio: Boolean,
) {
    IMSAK(index = 0, supportsAdhanAudio = true),
    SUNRISE(index = 1, supportsAdhanAudio = false),
    DHUHR(index = 2, supportsAdhanAudio = true),
    ASR(index = 3, supportsAdhanAudio = true),
    MAGHRIB(index = 4, supportsAdhanAudio = true),
    ISHA(index = 5, supportsAdhanAudio = true);

    companion object {
        fun fromIndex(index: Int): PrayerName? = entries.firstOrNull { it.index == index }
    }
}

enum class AsrMadhhab(val shadowFactor: Int) {
    STANDARD(1), // Shafi'i / Diyanet standard
    HANAFI(2),
}

enum class HighLatitudeRule {
    ANGLE_BASED,
    MIDDLE_OF_NIGHT,
    ONE_SEVENTH_OF_NIGHT,
}

enum class NotificationStage(val index: Int) {
    START(0),
    ONGOING(1),
    END(2);

    companion object {
        fun fromIndex(index: Int): NotificationStage? = entries.firstOrNull { it.index == index }
    }
}
