package com.example.adhan.data.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.TurkishCity
import com.example.adhan.domain.repository.LocationDetectionResult
import com.example.adhan.domain.repository.LocationRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

class LocationRepositoryImpl(
    private val context: Context,
    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context),
) : LocationRepository {

    override fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    override suspend fun detectCurrentLocation(): LocationDetectionResult {
        if (!hasLocationPermission()) {
            return LocationDetectionResult.PermissionMissing
        }

        val androidLocation = fetchFreshOrLastLocation() ?: return LocationDetectionResult.Unavailable

        val (city, district, geocoderFallback) = reverseGeocode(
            latitude = androidLocation.latitude,
            longitude = androidLocation.longitude,
        )

        return LocationDetectionResult.Success(
            location = LocationInfo(
                latitude = androidLocation.latitude,
                longitude = androidLocation.longitude,
                city = city,
                district = district,
                source = LocationSource.GPS,
                updatedAtEpochMs = System.currentTimeMillis(),
            ),
            usedGeocoderFallback = geocoderFallback,
        )
    }

    override fun getAllTurkishCities(): List<TurkishCity> = TurkishCitiesCatalog.cities

    override fun searchTurkishCities(query: String): List<TurkishCity> =
        TurkishCitiesCatalog.search(query)

    override fun defaultFallbackLocation(): LocationInfo {
        val istanbul = TurkishCitiesCatalog.defaultCity
        return LocationInfo(
            latitude = istanbul.latitude,
            longitude = istanbul.longitude,
            city = istanbul.name,
            district = istanbul.districts.firstOrNull()?.name ?: "Fatih",
            source = LocationSource.DEFAULT,
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetchFreshOrLastLocation(): Location? {
        val current = suspendCancellableCoroutine { continuation ->
            val cts = CancellationTokenSource()
            continuation.invokeOnCancellation { cts.cancel() }
            fusedLocationClient
                .getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
                .addOnSuccessListener { location ->
                    if (continuation.isActive) continuation.resume(location)
                }
                .addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
        }
        if (current != null) return current

        return suspendCancellableCoroutine { continuation ->
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (continuation.isActive) continuation.resume(location)
                }
                .addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
        }
    }

    private suspend fun reverseGeocode(
        latitude: Double,
        longitude: Double,
    ): Triple<String, String, Boolean> = withContext(Dispatchers.IO) {
        try {
            if (!Geocoder.isPresent()) {
                return@withContext fallbackFromCoordinates(latitude, longitude)
            }
            val geocoder = Geocoder(context, Locale.getDefault())
            val address: Address? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                suspendCancellableCoroutine { cont ->
                    geocoder.getFromLocation(latitude, longitude, 1, object : Geocoder.GeocodeListener {
                        override fun onGeocode(addresses: MutableList<Address>) {
                            if (cont.isActive) cont.resume(addresses.firstOrNull())
                        }

                        override fun onError(errorMessage: String?) {
                            if (cont.isActive) cont.resume(null)
                        }
                    })
                }
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocation(latitude, longitude, 1)?.firstOrNull()
            }

            if (address != null) {
                val city = address.adminArea?.takeIf { it.isNotBlank() }
                    ?: address.locality?.takeIf { it.isNotBlank() }
                    ?: address.countryName?.takeIf { it.isNotBlank() }
                val district = address.subAdminArea?.takeIf { it.isNotBlank() }
                    ?: address.locality?.takeIf { it.isNotBlank() && it != city }
                    ?: ""
                if (!city.isNullOrBlank()) {
                    return@withContext Triple(city, district, false)
                }
            }
        } catch (_: Exception) {
            // Geocoder can throw IOException offline or ServiceUnavailable; fall back gracefully
        }
        fallbackFromCoordinates(latitude, longitude)
    }

    private fun fallbackFromCoordinates(
        latitude: Double,
        longitude: Double,
    ): Triple<String, String, Boolean> {
        val nearestTurkishCity = TurkishCitiesCatalog.findNearestCity(latitude, longitude)
        return if (nearestTurkishCity != null) {
            Triple(nearestTurkishCity.name, "", true)
        } else {
            val formatted = String.format(Locale.US, "%.2f°, %.2f°", latitude, longitude)
            Triple(formatted, "", true)
        }
    }
}
