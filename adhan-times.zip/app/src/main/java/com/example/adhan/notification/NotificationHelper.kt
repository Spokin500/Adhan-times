package com.example.adhan.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.NotificationStage
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.service.AdhanAudioService

class NotificationHelper(
    private val context: Context,
) {
    companion object {
        const val CHANNEL_PRAYER_ALERTS = "adhan_prayer_alerts"
        const val CHANNEL_AUDIO_PLAYBACK = "adhan_audio_playback"
        const val NOTIFICATION_ID_AUDIO_FOREGROUND = 9001
        const val NOTIFICATION_ID_TEST = 9002
        const val NOTIFICATION_ID_AUDIO_ERROR = 9003

        fun notificationIdFor(prayer: PrayerName, stage: NotificationStage): Int =
            1000 + prayer.index * 10 + stage.index
    }

    fun ensureChannels(language: AppLanguage = AppLanguage.SYSTEM) {
        val locCtx = LocalizedContextProvider.localizedContext(context, language)
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val alertsChannel = NotificationChannel(
            CHANNEL_PRAYER_ALERTS,
            locCtx.getString(R.string.notif_channel_alerts_name),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = locCtx.getString(R.string.notif_channel_alerts_desc)
            enableVibration(true)
        }

        val audioChannel = NotificationChannel(
            CHANNEL_AUDIO_PLAYBACK,
            locCtx.getString(R.string.notif_channel_audio_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = locCtx.getString(R.string.notif_channel_audio_desc)
            setShowBadge(false)
        }

        manager.createNotificationChannel(alertsChannel)
        manager.createNotificationChannel(audioChannel)
    }

    fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun showPrayerStageNotification(
        prayer: PrayerName,
        stage: NotificationStage,
        language: AppLanguage,
        includeStopAdhanAction: Boolean,
    ) {
        if (!hasNotificationPermission()) return
        ensureChannels(language)
        val locCtx = LocalizedContextProvider.localizedContext(context, language)
        val prayerLabel = locCtx.getString(LocalizedContextProvider.prayerNameRes(prayer))

        val (title, body) = when (stage) {
            NotificationStage.START -> {
                locCtx.getString(R.string.notif_stage1_title, prayerLabel) to
                    locCtx.getString(R.string.notif_stage1_body, prayerLabel)
            }
            NotificationStage.ONGOING -> {
                locCtx.getString(R.string.notif_stage2_title, prayerLabel) to
                    locCtx.getString(R.string.notif_stage2_body)
            }
            NotificationStage.END -> {
                locCtx.getString(R.string.notif_stage3_title, prayerLabel) to
                    locCtx.getString(R.string.notif_stage3_body)
            }
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_PRAYER_ALERTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(createLaunchAppIntent())

        if (includeStopAdhanAction) {
            builder.addAction(
                android.R.drawable.ic_media_pause,
                locCtx.getString(R.string.notif_action_stop_adhan),
                createStopAdhanIntent(locCtx),
            )
        }

        NotificationManagerCompat.from(context)
            .notify(notificationIdFor(prayer, stage), builder.build())
    }

    /**
     * Sends a safe preview notification without ever starting Adhan audio.
     */
    fun sendTestNotification(language: AppLanguage): Boolean {
        if (!hasNotificationPermission()) return false
        ensureChannels(language)
        val locCtx = LocalizedContextProvider.localizedContext(context, language)

        val notification = NotificationCompat.Builder(context, CHANNEL_PRAYER_ALERTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(locCtx.getString(R.string.notif_test_title))
            .setContentText(locCtx.getString(R.string.notif_test_body))
            .setStyle(NotificationCompat.BigTextStyle().bigText(locCtx.getString(R.string.notif_test_body)))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(createLaunchAppIntent())
            .build()

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_TEST, notification)
        return true
    }

    fun showAudioMissingFallbackNotification(language: AppLanguage) {
        if (!hasNotificationPermission()) return
        ensureChannels(language)
        val locCtx = LocalizedContextProvider.localizedContext(context, language)

        val notification = NotificationCompat.Builder(context, CHANNEL_PRAYER_ALERTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(locCtx.getString(R.string.notif_audio_missing_title))
            .setContentText(locCtx.getString(R.string.notif_audio_missing_body))
            .setStyle(NotificationCompat.BigTextStyle().bigText(locCtx.getString(R.string.notif_audio_missing_body)))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(createLaunchAppIntent())
            .build()

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_AUDIO_ERROR, notification)
    }

    fun buildAudioPlaybackNotification(
        prayer: PrayerName,
        language: AppLanguage,
    ) = run {
        ensureChannels(language)
        val locCtx = LocalizedContextProvider.localizedContext(context, language)
        val prayerLabel = locCtx.getString(LocalizedContextProvider.prayerNameRes(prayer))
        NotificationCompat.Builder(context, CHANNEL_AUDIO_PLAYBACK)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(locCtx.getString(R.string.notif_audio_playing_title, prayerLabel))
            .setContentText(locCtx.getString(R.string.notif_audio_playing_subtitle))
            .setOngoing(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setContentIntent(createLaunchAppIntent())
            .addAction(
                android.R.drawable.ic_media_pause,
                locCtx.getString(R.string.notif_action_stop_adhan),
                createStopAdhanIntent(locCtx),
            )
            .build()
    }

    fun createLaunchAppIntent(): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    fun createStopAdhanIntent(locCtx: Context = context): PendingIntent {
        val stopIntent = Intent(locCtx, AdhanAudioService::class.java).apply {
            action = AdhanAudioService.ACTION_STOP_ADHAN
        }
        return PendingIntent.getService(
            locCtx,
            7701,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
