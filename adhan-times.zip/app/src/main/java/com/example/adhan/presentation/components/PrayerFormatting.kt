package com.example.adhan.presentation.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.WbShade
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.data.local.LanguageResolver
import java.time.format.DateTimeFormatter
import java.util.Locale

fun prayerIcon(prayer: PrayerName): ImageVector = when (prayer) {
    PrayerName.IMSAK -> Icons.Rounded.NightsStay
    PrayerName.SUNRISE -> Icons.Rounded.WbTwilight
    PrayerName.DHUHR -> Icons.Rounded.WbSunny
    PrayerName.ASR -> Icons.Rounded.LightMode
    PrayerName.MAGHRIB -> Icons.Rounded.WbShade
    PrayerName.ISHA -> Icons.Rounded.Bedtime
}

fun formatCountdownMillis(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) / 1000L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
}

fun formatGregorianDate(times: DailyPrayerTimes, language: AppLanguage): String {
    val locale = LanguageResolver.resolveLocale(language)
    val formatter = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", locale)
    return times.date.format(formatter)
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
}

fun formatHijriDate(times: DailyPrayerTimes, language: AppLanguage): String {
    val locale = LanguageResolver.resolveLocale(language)
    val isTurkish = locale.language == "tr"
    val monthsTr = listOf(
        "Muharrem", "Safer", "Rebiülevvel", "Rebiülahir",
        "Cemaziyelevvel", "Cemaziyelahir", "Recep", "Şaban",
        "Ramazan", "Şevval", "Zilkade", "Zilhicce",
    )
    val monthsEn = listOf(
        "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
        "Jumada al-Awwal", "Jumada al-Thani", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah",
    )
    val monthName = (if (isTurkish) monthsTr else monthsEn)
        .getOrElse(times.hijriMonth - 1) { "" }
    val suffix = if (isTurkish) "H" else "AH"
    return "${times.hijriDay} $monthName ${times.hijriYear} $suffix"
}
