package com.example.adhan.presentation.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.NextPrayerState
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.repository.LocationDetectionResult
import com.example.adhan.domain.repository.LocationRepository
import com.example.adhan.domain.repository.SettingsRepository
import com.example.adhan.domain.usecase.ComputeNextPrayerUseCase
import com.example.adhan.domain.usecase.GetDailyPrayerTimesUseCase
import com.example.adhan.notification.NotificationHelper
import com.example.adhan.service.AdhanPlaybackController
import com.example.adhan.service.AlarmScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class PrayerRowStatus {
    PASSED,
    NEXT,
    UPCOMING,
}

data class PrayerScheduleRow(
    val prayer: PrayerName,
    val formattedTime: String,
    val status: PrayerRowStatus,
)

data class HomeUiState(
    val isLoading: Boolean = true,
    val location: LocationInfo? = null,
    val todayTimes: DailyPrayerTimes? = null,
    val tomorrowTimes: DailyPrayerTimes? = null,
    val nextPrayerState: NextPrayerState? = null,
    val rows: List<PrayerScheduleRow> = emptyList(),
    val appLanguage: AppLanguage = AppLanguage.SYSTEM,
    val hasLocationPermission: Boolean = false,
    val hasNotificationPermission: Boolean = true,
    val canScheduleExactAlarms: Boolean = true,
    val isRefreshingLocation: Boolean = false,
    val isAdhanAudioPlaying: Boolean = false,
    val statusMessageResId: Int? = null,
)

class HomeViewModel(
    private val appContext: Context,
    private val settingsRepository: SettingsRepository,
    private val locationRepository: LocationRepository,
    private val getDailyPrayerTimesUseCase: GetDailyPrayerTimesUseCase,
    private val computeNextPrayerUseCase: ComputeNextPrayerUseCase,
    private val alarmScheduler: AlarmScheduler,
    private val notificationHelper: NotificationHelper,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private var currentPreferences: UserPreferences = UserPreferences()
    private var cachedTodayDate: LocalDate? = null
    private var cachedZoneId: ZoneId = ZoneId.systemDefault()
    private var cachedTodayTimes: DailyPrayerTimes? = null
    private var cachedTomorrowTimes: DailyPrayerTimes? = null
    private var autoLocationAttempted = false

    init {
        observePreferences()
        observePlaybackState()
        startCountdownTicker()
    }

    private fun observePreferences() {
        viewModelScope.launch {
            settingsRepository.preferencesFlow.collectLatest { prefs ->
                currentPreferences = prefs
                val resolvedLocation = prefs.savedLocation ?: locationRepository.defaultFallbackLocation()
                recalculateDailySchedules(resolvedLocation, prefs)
                refreshPermissionsSnapshot()

                if (prefs.savedLocation == null && !autoLocationAttempted && locationRepository.hasLocationPermission()) {
                    autoLocationAttempted = true
                    refreshGpsLocation()
                }
            }
        }
    }

    private fun observePlaybackState() {
        viewModelScope.launch {
            AdhanPlaybackController.isPlaying.collectLatest { playing ->
                _uiState.update { it.copy(isAdhanAudioPlaying = playing) }
            }
        }
    }

    private fun startCountdownTicker() {
        viewModelScope.launch {
            while (true) {
                updateLiveCountdown()
                delay(1000L)
            }
        }
    }

    private fun recalculateDailySchedules(location: LocationInfo, prefs: UserPreferences) {
        val zoneId = ZoneId.systemDefault()
        val today = LocalDate.now(zoneId)
        val tomorrow = today.plusDays(1)

        val todayTimes = getDailyPrayerTimesUseCase(today, location, zoneId, prefs.asrMadhhab)
        val tomorrowTimes = getDailyPrayerTimesUseCase(tomorrow, location, zoneId, prefs.asrMadhhab)

        cachedTodayDate = today
        cachedZoneId = zoneId
        cachedTodayTimes = todayTimes
        cachedTomorrowTimes = tomorrowTimes

        updateLiveCountdown()
    }

    private fun updateLiveCountdown() {
        val zoneId = ZoneId.systemDefault()
        val nowDate = LocalDate.now(zoneId)
        val todayTimes = cachedTodayTimes
        val tomorrowTimes = cachedTomorrowTimes

        if (todayTimes == null || tomorrowTimes == null || nowDate != cachedTodayDate || zoneId != cachedZoneId) {
            val location = currentPreferences.savedLocation ?: locationRepository.defaultFallbackLocation()
            recalculateDailySchedules(location, currentPreferences)
            return
        }

        val now = Instant.now()
        val nextState = computeNextPrayerUseCase(now, todayTimes, tomorrowTimes)
        val nextPrayerToday = if (!nextState.isTomorrow) nextState.nextPrayer.prayer else null

        val rows = todayTimes.entries.map { entry ->
            val status = when {
                nextState.isTomorrow -> PrayerRowStatus.PASSED
                entry.prayer == nextPrayerToday -> PrayerRowStatus.NEXT
                entry.instant.isBefore(now) || entry.instant == now -> PrayerRowStatus.PASSED
                else -> PrayerRowStatus.UPCOMING
            }
            val formatted = String.format(
                "%02d:%02d",
                entry.time.hour,
                entry.time.minute,
            )
            PrayerScheduleRow(
                prayer = entry.prayer,
                formattedTime = formatted,
                status = status,
            )
        }

        _uiState.update {
            it.copy(
                isLoading = false,
                location = todayTimes.location,
                todayTimes = todayTimes,
                tomorrowTimes = tomorrowTimes,
                nextPrayerState = nextState,
                rows = rows,
                appLanguage = currentPreferences.appLanguage,
            )
        }
    }

    fun onAppResumed() {
        refreshPermissionsSnapshot()
        updateLiveCountdown()
    }

    fun refreshPermissionsSnapshot() {
        _uiState.update {
            it.copy(
                hasLocationPermission = locationRepository.hasLocationPermission(),
                hasNotificationPermission = notificationHelper.hasNotificationPermission(),
                canScheduleExactAlarms = alarmScheduler.canScheduleExactAlarms(),
            )
        }
    }

    fun refreshGpsLocation() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingLocation = true, statusMessageResId = null) }
            when (val result = locationRepository.detectCurrentLocation()) {
                is LocationDetectionResult.Success -> {
                    settingsRepository.saveLocation(result.location)
                    alarmScheduler.rescheduleAll()
                    _uiState.update {
                        it.copy(
                            isRefreshingLocation = false,
                            hasLocationPermission = true,
                            statusMessageResId = if (result.usedGeocoderFallback) {
                                com.example.R.string.location_geocoder_fallback
                            } else {
                                null
                            },
                        )
                    }
                }
                LocationDetectionResult.PermissionMissing -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingLocation = false,
                            hasLocationPermission = false,
                        )
                    }
                }
                LocationDetectionResult.Unavailable -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingLocation = false,
                            statusMessageResId = com.example.R.string.location_error_unavailable,
                        )
                    }
                }
            }
        }
    }

    fun stopAdhanAudio() {
        AdhanPlaybackController.stopAdhan(appContext)
    }

    fun dismissStatusMessage() {
        _uiState.update { it.copy(statusMessageResId = null) }
    }
}
