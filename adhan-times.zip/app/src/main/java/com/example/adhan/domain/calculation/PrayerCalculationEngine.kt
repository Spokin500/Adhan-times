package com.example.adhan.domain.calculation

import com.example.adhan.domain.model.CalculationParameters
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.LocationInfo
import java.time.LocalDate
import java.time.ZoneId

interface PrayerCalculationEngine {
    fun calculate(
        date: LocalDate,
        location: LocationInfo,
        zoneId: ZoneId,
        parameters: CalculationParameters = CalculationParameters(),
    ): DailyPrayerTimes
}
