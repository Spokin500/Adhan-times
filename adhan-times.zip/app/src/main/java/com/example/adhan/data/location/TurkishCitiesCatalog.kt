package com.example.adhan.data.location

import com.example.adhan.domain.model.TurkishCity
import com.example.adhan.domain.model.TurkishDistrict
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Offline catalog of all 81 provinces of Turkey with representative coordinates and major districts.
 */
object TurkishCitiesCatalog {

    val defaultCity: TurkishCity
        get() = cities.first { it.plateCode == 34 } // Istanbul

    val cities: List<TurkishCity> = listOf(
        city(1, "Adana", 37.0000, 35.3213, listOf("Seyhan", "Çukurova", "Yüreğir", "Sarıçam", "Ceyhan", "Kozan")),
        city(2, "Adıyaman", 37.7648, 38.2786, listOf("Merkez", "Kahta", "Besni", "Gölbaşı")),
        city(3, "Afyonkarahisar", 38.7507, 30.5567, listOf("Merkez", "Sandıklı", "Dinar", "Bolvadin")),
        city(4, "Ağrı", 39.7191, 43.0503, listOf("Merkez", "Doğubayazıt", "Patnos", "Eleşkirt")),
        city(5, "Amasya", 40.6499, 35.8353, listOf("Merkez", "Merzifon", "Suluova", "Taşova")),
        city(6, "Ankara", 39.9334, 32.8597, listOf(
            "Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Etimesgut", "Sincan", "Altındağ", "Gölbaşı", "Polatlı",
        )),
        city(7, "Antalya", 36.8969, 30.7133, listOf(
            "Muratpaşa", "Konyaaltı", "Kepez", "Alanya", "Manavgat", "Kaş", "Kemer", "Serik",
        )),
        city(8, "Artvin", 41.1828, 41.8183, listOf("Merkez", "Hopa", "Arhavi", "Borçka")),
        city(9, "Aydın", 37.8560, 27.8416, listOf("Efeler", "Kuşadası", "Nazilli", "Söke", "Didim")),
        city(10, "Balıkesir", 39.6484, 27.8826, listOf("Altıeylül", "Karesi", "Bandırma", "Edremit", "Ayvalık", "Gönen")),
        city(11, "Bilecik", 40.1451, 29.9799, listOf("Merkez", "Bozüyük", "Osmaneli", "Söğüt")),
        city(12, "Bingöl", 38.8855, 40.4966, listOf("Merkez", "Genç", "Solhan", "Karlıova")),
        city(13, "Bitlis", 38.4006, 42.1095, listOf("Merkez", "Tatvan", "Ahlat", "Güroymak")),
        city(14, "Bolu", 40.7350, 31.6061, listOf("Merkez", "Gerede", "Mudurnu", "Göynük")),
        city(15, "Burdur", 37.7203, 30.2908, listOf("Merkez", "Bucak", "Gölhisar", "Yeşilova")),
        city(16, "Bursa", 40.1885, 29.0610, listOf(
            "Osmangazi", "Nilüfer", "Yıldırım", "İnegöl", "Mudanya", "Gemlik", "Mustafakemalpaşa",
        )),
        city(17, "Çanakkale", 40.1553, 26.4142, listOf("Merkez", "Biga", "Çan", "Gelibolu", "Ayvacık")),
        city(18, "Çankırı", 40.6013, 33.6134, listOf("Merkez", "Çerkeş", "Ilgaz", "Kurşunlu")),
        city(19, "Çorum", 40.5506, 34.9556, listOf("Merkez", "Sungurlu", "Osmancık", "İskilip")),
        city(20, "Denizli", 37.7765, 29.0864, listOf("Pamukkale", "Merkezefendi", "Çivril", "Acıpayam")),
        city(21, "Diyarbakır", 37.9144, 40.2306, listOf("Bağlar", "Kayapınar", "Yenişehir", "Sur", "Ergani", "Bismil")),
        city(22, "Edirne", 41.6771, 26.5557, listOf("Merkez", "Keşan", "Uzunköprü", "İpsala")),
        city(23, "Elazığ", 38.6810, 39.2264, listOf("Merkez", "Kovancılar", "Karakoçan", "Palu")),
        city(24, "Erzincan", 39.7500, 39.5000, listOf("Merkez", "Tercan", "Üzümlü", "Refahiye")),
        city(25, "Erzurum", 39.9000, 41.2700, listOf("Yakutiye", "Palandöken", "Aziziye", "Oltu", "Horasan")),
        city(26, "Eskişehir", 39.7767, 30.5206, listOf("Odunpazarı", "Tepebaşı", "Sivrihisar", "Çifteler")),
        city(27, "Gaziantep", 37.0662, 37.3833, listOf("Şahinbey", "Şehitkamil", "Nizip", "İslahiye")),
        city(28, "Giresun", 40.9128, 38.3895, listOf("Merkez", "Bulancak", "Espiye", "Görele")),
        city(29, "Gümüşhane", 40.4603, 39.4814, listOf("Merkez", "Kelkit", "Şiran", "Torul")),
        city(30, "Hakkari", 37.5744, 43.7408, listOf("Merkez", "Yüksekova", "Şemdinli", "Çukurca")),
        city(31, "Hatay", 36.2023, 36.1613, listOf("Antakya", "Defne", "İskenderun", "Samandağ", "Dörtyol", "Reyhanlı")),
        city(32, "Isparta", 37.7648, 30.5566, listOf("Merkez", "Yalvaç", "Eğirdir", "Şarkikaraağaç")),
        city(33, "Mersin", 36.8121, 34.6415, listOf("Yenişehir", "Mezitli", "Toroslar", "Akdeniz", "Tarsus", "Erdemli", "Silifke")),
        city(34, "İstanbul", 41.0082, 28.9784, listOf(
            "Fatih", "Üsküdar", "Kadıköy", "Beşiktaş", "Eyüpsultan", "Beyoğlu", "Bakırköy",
            "Başakşehir", "Ümraniye", "Pendik", "Maltepe", "Kartal", "Sarıyer", "Bağcılar",
        )),
        city(35, "İzmir", 38.4237, 27.1428, listOf(
            "Konak", "Karşıyaka", "Bornova", "Buca", "Bayraklı", "Çiğli", "Menemen", "Torbalı", "Çeşme",
        )),
        city(36, "Kars", 40.6013, 43.0975, listOf("Merkez", "Sarıkamış", "Kağızman", "Digor")),
        city(37, "Kastamonu", 41.3887, 33.7827, listOf("Merkez", "Tosya", "Taşköprü", "İnebolu")),
        city(38, "Kayseri", 38.7312, 35.4787, listOf("Melikgazi", "Kocasinan", "Talas", "Develi", "Yahyalı")),
        city(39, "Kırklareli", 41.7333, 27.2167, listOf("Merkez", "Lüleburgaz", "Babaeski", "Vize")),
        city(40, "Kırşehir", 39.1425, 34.1709, listOf("Merkez", "Kaman", "Mucur", "Çiçekdağı")),
        city(41, "Kocaeli", 40.8533, 29.8815, listOf("İzmit", "Gebze", "Darıca", "Gölcük", "Körfez", "Derince")),
        city(42, "Konya", 37.8746, 32.4932, listOf("Selçuklu", "Meram", "Karatay", "Ereğli", "Akşehir", "Beyşehir")),
        city(43, "Kütahya", 39.4167, 29.9833, listOf("Merkez", "Tavşanlı", "Simav", "Gediz")),
        city(44, "Malatya", 38.3552, 38.3095, listOf("Battalgazi", "Yeşilyurt", "Doğanşehir", "Darende")),
        city(45, "Manisa", 38.6191, 27.4289, listOf("Yunusemre", "Şehzadeler", "Akhisar", "Turgutlu", "Salihli", "Soma")),
        city(46, "Kahramanmaraş", 37.5858, 36.9371, listOf("Onikişubat", "Dulkadiroğlu", "Elbistan", "Afşin")),
        city(47, "Mardin", 37.3212, 40.7245, listOf("Artuklu", "Kızıltepe", "Midyat", "Nusaybin")),
        city(48, "Muğla", 37.2153, 28.3636, listOf("Menteşe", "Bodrum", "Fethiye", "Marmaris", "Milas", "Datça")),
        city(49, "Muş", 38.7432, 41.5064, listOf("Merkez", "Bulanık", "Malazgirt", "Varto")),
        city(50, "Nevşehir", 38.6244, 34.7239, listOf("Merkez", "Ürgüp", "Avanos", "Gülşehir")),
        city(51, "Niğde", 37.9667, 34.6833, listOf("Merkez", "Bor", "Ulukışla", "Çamardı")),
        city(52, "Ordu", 40.9839, 37.8764, listOf("Altınordu", "Ünye", "Fatsa", "Perşembe")),
        city(53, "Rize", 41.0201, 40.5234, listOf("Merkez", "Çayeli", "Ardeşen", "Pazar")),
        city(54, "Sakarya", 40.7569, 30.3783, listOf("Adapazarı", "Serdivan", "Erenler", "Hendek", "Akyazı", "Sapanca")),
        city(55, "Samsun", 41.2867, 36.3300, listOf("İlkadım", "Atakum", "Canik", "Bafra", "Çarşamba")),
        city(56, "Siirt", 37.9333, 41.9500, listOf("Merkez", "Kurtalan", "Pervari", "Baykan")),
        city(57, "Sinop", 42.0231, 35.1531, listOf("Merkez", "Boyabat", "Gerze", "Ayancık")),
        city(58, "Sivas", 39.7477, 37.0179, listOf("Merkez", "Şarkışla", "Yıldızeli", "Suşehri", "Divriği")),
        city(59, "Tekirdağ", 40.9781, 27.5110, listOf("Süleymanpaşa", "Çorlu", "Çerkezköy", "Kapaklı")),
        city(60, "Tokat", 40.3167, 36.5500, listOf("Merkez", "Erbaa", "Turhal", "Niksar", "Zile")),
        city(61, "Trabzon", 41.0027, 39.7168, listOf("Ortahisar", "Akçaabat", "Araklı", "Of", "Yomra")),
        city(62, "Tunceli", 39.1079, 39.5401, listOf("Merkez", "Pertek", "Hozat", "Ovacık")),
        city(63, "Şanlıurfa", 37.1674, 38.7955, listOf("Eyyübiye", "Haliliye", "Karaköprü", "Siverek", "Viranşehir")),
        city(64, "Uşak", 38.6823, 29.4082, listOf("Merkez", "Banaz", "Eşme", "Ulubey")),
        city(65, "Van", 38.4891, 43.4089, listOf("İpekyolu", "Tuşba", "Edremit", "Erciş")),
        city(66, "Yozgat", 39.8181, 34.8147, listOf("Merkez", "Sorgun", "Akdağmadeni", "Yerköy")),
        city(67, "Zonguldak", 41.4564, 31.7987, listOf("Merkez", "Ereğli", "Çaycuma", "Devrek")),
        city(68, "Aksaray", 38.3687, 34.0370, listOf("Merkez", "Ortaköy", "Eskil", "Güzelyurt")),
        city(69, "Bayburt", 40.2552, 40.2249, listOf("Merkez", "Demirözü", "Aydıntepe")),
        city(70, "Karaman", 37.1759, 33.2287, listOf("Merkez", "Ermenek", "Sarıveliler")),
        city(71, "Kırıkkale", 39.8468, 33.5153, listOf("Merkez", "Yahşihan", "Keskin")),
        city(72, "Batman", 37.8812, 41.1351, listOf("Merkez", "Kozluk", "Sason", "Beşiri")),
        city(73, "Şırnak", 37.5164, 42.4611, listOf("Merkez", "Cizre", "Silopi", "İdil")),
        city(74, "Bartın", 41.6344, 32.3375, listOf("Merkez", "Amasra", "Ulus", "Kurucaşile")),
        city(75, "Ardahan", 41.1105, 42.7022, listOf("Merkez", "Göle", "Çıldır")),
        city(76, "Iğdır", 39.9167, 44.0333, listOf("Merkez", "Tuzluca", "Aralık")),
        city(77, "Yalova", 40.6500, 29.2667, listOf("Merkez", "Çiftlikköy", "Çınarcık", "Altınova")),
        city(78, "Karabük", 41.2061, 32.6204, listOf("Merkez", "Safranbolu", "Yenice", "Eskipazar")),
        city(79, "Kilis", 36.7184, 37.1212, listOf("Merkez", "Musabeyli", "Elbeyli")),
        city(80, "Osmaniye", 37.0742, 36.2478, listOf("Merkez", "Kadirli", "Düziçi", "Bahçe")),
        city(81, "Düzce", 40.8438, 31.1565, listOf("Merkez", "Akçakoca", "Kaynaşlı", "Cumayeri")),
    )

    fun search(query: String): List<TurkishCity> {
        val normalizedQuery = normalizeTurkish(query.trim())
        if (normalizedQuery.isEmpty()) return cities
        return cities.filter { city ->
            normalizeTurkish(city.name).contains(normalizedQuery) ||
                city.plateCode.toString().padStart(2, '0').contains(normalizedQuery) ||
                city.districts.any { normalizeTurkish(it.name).contains(normalizedQuery) }
        }
    }

    fun findNearestCity(latitude: Double, longitude: Double): TurkishCity? {
        var nearest: TurkishCity? = null
        var minDistanceKm = Double.MAX_VALUE
        for (city in cities) {
            val dKm = haversineKm(latitude, longitude, city.latitude, city.longitude)
            if (dKm < minDistanceKm) {
                minDistanceKm = dKm
                nearest = city
            }
        }
        return if (minDistanceKm <= 160.0) nearest else null
    }

    fun normalizeTurkish(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text.lowercase(Locale.forLanguageTag("tr"))) {
            when (ch) {
                'ç' -> sb.append('c')
                'ğ' -> sb.append('g')
                'ı', 'İ', 'i' -> sb.append('i')
                'ö' -> sb.append('o')
                'ş' -> sb.append('s')
                'ü' -> sb.append('u')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun city(
        plateCode: Int,
        name: String,
        latitude: Double,
        longitude: Double,
        districtNames: List<String>,
    ): TurkishCity {
        val districts = districtNames.map { districtName ->
            TurkishDistrict(
                name = districtName,
                latitude = latitude,
                longitude = longitude,
            )
        }
        return TurkishCity(
            plateCode = plateCode,
            name = name,
            latitude = latitude,
            longitude = longitude,
            districts = districts,
        )
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }
}
