package com.example.adhan.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.adhan.AdhanApplication
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.NotificationStage
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.repository.LocationRepository
import com.example.adhan.domain.repository.PrayerTimesRepository
import com.example.adhan.domain.repository.SettingsRepository
import com.example.adhan.receiver.AlarmReceiver
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit

class AlarmScheduler(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val prayerTimesRepository: PrayerTimesRepository,
    private val locationRepository: LocationRepository,
) {
    private val alarmManager: AlarmManager? = context.getSystemService(AlarmManager::class.java)

    companion object {
        private const val WORK_DAILY_REFRESH = "adhan_daily_alarm_refresh"
    }

    fun canScheduleExactAlarms(): Boolean {
        val am = alarmManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            am.canScheduleExactAlarms()
        } else {
            true
        }
    }

    suspend fun rescheduleAll(now: Instant = Instant.now(), zoneId: ZoneId = ZoneId.systemDefault()) {
        val prefs = settingsRepository.getCurrentPreferences()
        cancelAllAlarms()

        if (!prefs.notificationsEnabled && !prefs.enableAdhanAudio) {
            return
        }

        val location = prefs.savedLocation ?: locationRepository.defaultFallbackLocation()
        val today = now.atZone(zoneId).toLocalDate()
        val tomorrow = today.plusDays(1)

        val todayTimes = prayerTimesRepository.getPrayerTimes(today, location, zoneId, prefs.asrMadhhab)
        val tomorrowTimes = prayerTimesRepository.getPrayerTimes(tomorrow, location, zoneId, prefs.asrMadhhab)

        scheduleDayAlarms(todayTimes, dayOffset = 0, now = now, prefs = prefs)
        scheduleDayAlarms(tomorrowTimes, dayOffset = 1, now = now, prefs = prefs)
        ensureDailyRefreshWorker()
    }

    fun cancelAllAlarms() {
        val am = alarmManager ?: return
        for (dayOffset in 0..1) {
            for (prayer in PrayerName.entries) {
                for (stage in NotificationStage.entries) {
                    val pendingIntent = createAlarmPendingIntent(
                        prayer = prayer,
                        stage = stage,
                        dateIso = "",
                        dayOffset = dayOffset,
                        flags = PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
                    )
                    if (pendingIntent != null) {
                        am.cancel(pendingIntent)
                        pendingIntent.cancel()
                    }
                }
            }
        }
    }

    private fun scheduleDayAlarms(
        dailyTimes: DailyPrayerTimes,
        dayOffset: Int,
        now: Instant,
        prefs: UserPreferences,
    ) {
        val am = alarmManager ?: return
        val dateIso = dailyTimes.date.toString()

        for (entry in dailyTimes.entries) {
            // Sunrise has no Adhan stages unless notifications are enabled for start reminder
            val stages = if (entry.prayer == PrayerName.SUNRISE) {
                listOf(NotificationStage.START)
            } else {
                NotificationStage.entries
            }

            for (stage in stages) {
                val triggerInstant = when (stage) {
                    NotificationStage.START -> entry.instant
                    NotificationStage.ONGOING -> entry.instant.plusSeconds(prefs.stage2DelayMinutes * 60L)
                    NotificationStage.END -> entry.instant.plusSeconds(prefs.stage3DelayMinutes * 60L)
                }

                if (!triggerInstant.isAfter(now)) continue

                val pi = createAlarmPendingIntent(
                    prayer = entry.prayer,
                    stage = stage,
                    dateIso = dateIso,
                    dayOffset = dayOffset,
                    flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                ) ?: continue

                val triggerAtMillis = triggerInstant.toEpochMilli()
                if (canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                }
            }
        }
    }

    private fun createAlarmPendingIntent(
        prayer: PrayerName,
        stage: NotificationStage,
        dateIso: String,
        dayOffset: Int,
        flags: Int,
    ): PendingIntent? {
        val requestCode = dayOffset * 100 + prayer.index * 10 + stage.index
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_PRAYER_ALARM
            putExtra(AlarmReceiver.EXTRA_PRAYER_INDEX, prayer.index)
            putExtra(AlarmReceiver.EXTRA_STAGE_INDEX, stage.index)
            putExtra(AlarmReceiver.EXTRA_DATE_ISO, dateIso)
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }

    private fun ensureDailyRefreshWorker() {
        val request = PeriodicWorkRequestBuilder<DailyAlarmRefreshWorker>(
            12,
            TimeUnit.HOURS,
        ).build()

        runCatching {
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_DAILY_REFRESH,
                ExistingPeriodicWorkPolicy.KEEP,
                request,
            )
        }
    }
}

class DailyAlarmRefreshWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as? AdhanApplication ?: return Result.success()
        app.appContainer.alarmScheduler.rescheduleAll()
        return Result.success()
    }
}
