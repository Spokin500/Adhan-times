package com.example.adhan.domain.calculation

import com.example.adhan.domain.model.CalculationParameters
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.HighLatitudeRule
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.PrayerName
import com.example.adhan.domain.model.PrayerTimeEntry
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

/**
 * Offline solar astronomical prayer time calculator aligned with Diyanet-compatible angular parameters
 * (Fajr 18.0°, Isha 17.0°, Sunset/Sunrise refraction 0.8333°).
 *
 * Transparency note: Official Diyanet calendars also incorporate site-specific horizon/elevation
 * temkin margins. This offline engine computes pure astronomical times (`isOfficialDiyanetData = false`)
 * directly in UTC instants and converts to [ZoneId], preventing DST transition artifacts.
 */
class DiyanetAstronomicalCalculator : PrayerCalculationEngine {

    override fun calculate(
        date: LocalDate,
        location: LocationInfo,
        zoneId: ZoneId,
        parameters: CalculationParameters,
    ): DailyPrayerTimes {
        val lat = location.latitude.coerceIn(-89.9, 89.9)
        val lon = location.longitude.coerceIn(-180.0, 180.0)

        // Anchor UTC midnight close to the local civil day's solar noon so longitudes across +/-180 work cleanly
        val localNoonInstant = ZonedDateTime.of(date, LocalTime.NOON, zoneId).toInstant()
        val approxUtcNoonDate = localNoonInstant.atZone(ZoneOffset.UTC).toLocalDate()
        val jdBase0hUtc = julianDay0hUtc(approxUtcNoonDate)

        // First pass: evaluate solar position at approximate solar noon JD
        val approxTransitUtcHours = 12.0 - lon / 15.0
        val jdTransitApprox = jdBase0hUtc + approxTransitUtcHours / 24.0
        val solarNoonPos = computeSolarPosition(jdTransitApprox)
        val dhuhrUtcHours = 12.0 - lon / 15.0 - solarNoonPos.equationOfTimeHours

        // Refine solar position at computed Dhuhr JD
        val jdDhuhr = jdBase0hUtc + dhuhrUtcHours / 24.0
        val sun = computeSolarPosition(jdDhuhr)
        val dhuhrRefinedUtc = 12.0 - lon / 15.0 - sun.equationOfTimeHours

        val sunriseHourAngle = hourAngleForAltitude(
            latitudeDeg = lat,
            declinationRad = sun.declinationRad,
            altitudeDeg = -parameters.sunriseDepressionDegrees,
        )

        val sunriseUtc = if (sunriseHourAngle != null) {
            dhuhrRefinedUtc - sunriseHourAngle
        } else {
            // Polar day/night fallback
            dhuhrRefinedUtc - 6.0
        }

        val maghribUtc = if (sunriseHourAngle != null) {
            dhuhrRefinedUtc + sunriseHourAngle
        } else {
            dhuhrRefinedUtc + 6.0
        }

        val nightDuration = (sunriseUtc + 24.0) - maghribUtc

        val fajrHourAngle = hourAngleForAltitude(
            latitudeDeg = lat,
            declinationRad = sun.declinationRad,
            altitudeDeg = -parameters.fajrAngleDegrees,
        )
        val fajrUtc = if (fajrHourAngle != null) {
            dhuhrRefinedUtc - fajrHourAngle
        } else {
            sunriseUtc - highLatitudeNightPortion(
                angleDegrees = parameters.fajrAngleDegrees,
                nightHours = nightDuration,
                rule = parameters.highLatitudeRule,
            )
        }

        val ishaHourAngle = hourAngleForAltitude(
            latitudeDeg = lat,
            declinationRad = sun.declinationRad,
            altitudeDeg = -parameters.ishaAngleDegrees,
        )
        val ishaUtc = if (ishaHourAngle != null) {
            dhuhrRefinedUtc + ishaHourAngle
        } else {
            maghribUtc + highLatitudeNightPortion(
                angleDegrees = parameters.ishaAngleDegrees,
                nightHours = nightDuration,
                rule = parameters.highLatitudeRule,
            )
        }

        val asrUtc = computeAsrUtcHours(
            dhuhrUtc = dhuhrRefinedUtc,
            latitudeDeg = lat,
            declinationRad = sun.declinationRad,
            shadowFactor = parameters.asrMadhhab.shadowFactor,
        )

        val utcDayStart = approxUtcNoonDate.atStartOfDay(ZoneOffset.UTC).toInstant()

        val entries = listOf(
            PrayerTimeEntry(PrayerName.IMSAK, utcHoursToZoned(utcDayStart, fajrUtc, zoneId)),
            PrayerTimeEntry(PrayerName.SUNRISE, utcHoursToZoned(utcDayStart, sunriseUtc, zoneId)),
            PrayerTimeEntry(PrayerName.DHUHR, utcHoursToZoned(utcDayStart, dhuhrRefinedUtc, zoneId)),
            PrayerTimeEntry(PrayerName.ASR, utcHoursToZoned(utcDayStart, asrUtc, zoneId)),
            PrayerTimeEntry(PrayerName.MAGHRIB, utcHoursToZoned(utcDayStart, maghribUtc, zoneId)),
            PrayerTimeEntry(PrayerName.ISHA, utcHoursToZoned(utcDayStart, ishaUtc, zoneId)),
        )

        val hijrah = HijrahDate.from(date)

        return DailyPrayerTimes(
            date = date,
            zoneId = zoneId,
            location = location,
            entries = entries,
            parameters = parameters,
            hijriDay = hijrah.get(ChronoField.DAY_OF_MONTH),
            hijriMonth = hijrah.get(ChronoField.MONTH_OF_YEAR),
            hijriYear = hijrah.get(ChronoField.YEAR),
        )
    }

    private fun utcHoursToZoned(
        utcDayStart: Instant,
        utcHours: Double,
        zoneId: ZoneId,
    ): ZonedDateTime {
        val seconds = (utcHours * 3600.0).roundToLong()
        return utcDayStart.plusSeconds(seconds).atZone(zoneId)
    }

    private fun computeAsrUtcHours(
        dhuhrUtc: Double,
        latitudeDeg: Double,
        declinationRad: Double,
        shadowFactor: Int,
    ): Double {
        val latRad = Math.toRadians(latitudeDeg)
        val zenithDiff = abs(latRad - declinationRad)
        val altitudeRad = atan(1.0 / (shadowFactor.toDouble() + tan(zenithDiff)))
        val altitudeDeg = Math.toDegrees(altitudeRad)
        val hourAngle = hourAngleForAltitude(latitudeDeg, declinationRad, altitudeDeg)
        return dhuhrUtc + (hourAngle ?: 3.5)
    }

    private fun hourAngleForAltitude(
        latitudeDeg: Double,
        declinationRad: Double,
        altitudeDeg: Double,
    ): Double? {
        val latRad = Math.toRadians(latitudeDeg)
        val altRad = Math.toRadians(altitudeDeg)
        val cosDenominator = cos(latRad) * cos(declinationRad)
        if (abs(cosDenominator) < 1e-10) return null
        val cosHourAngle = (sin(altRad) - sin(latRad) * sin(declinationRad)) / cosDenominator
        if (cosHourAngle < -1.0 || cosHourAngle > 1.0) return null
        return Math.toDegrees(acos(cosHourAngle)) / 15.0
    }

    private fun highLatitudeNightPortion(
        angleDegrees: Double,
        nightHours: Double,
        rule: HighLatitudeRule,
    ): Double {
        val safeNight = nightHours.coerceIn(1.0, 23.0)
        return when (rule) {
            HighLatitudeRule.ANGLE_BASED -> safeNight * (angleDegrees / 60.0)
            HighLatitudeRule.MIDDLE_OF_NIGHT -> safeNight * 0.5
            HighLatitudeRule.ONE_SEVENTH_OF_NIGHT -> safeNight / 7.0
        }
    }

    private data class SolarPosition(
        val declinationRad: Double,
        val equationOfTimeHours: Double,
    )

    private fun computeSolarPosition(julianDay: Double): SolarPosition {
        val d = julianDay - 2451545.0
        val gDeg = normalizeDegrees(357.529 + 0.98560028 * d)
        val qDeg = normalizeDegrees(280.459 + 0.98564736 * d)
        val gRad = Math.toRadians(gDeg)

        val lDeg = normalizeDegrees(qDeg + 1.915 * sin(gRad) + 0.020 * sin(2.0 * gRad))
        val lRad = Math.toRadians(lDeg)

        val eDeg = 23.439 - 0.00000036 * d
        val eRad = Math.toRadians(eDeg)

        val raRad = atan2(cos(eRad) * sin(lRad), cos(lRad))
        val raHours = normalizeHours(Math.toDegrees(raRad) / 15.0)
        val declRad = asin((sin(eRad) * sin(lRad)).coerceIn(-1.0, 1.0))

        var eqTime = (qDeg / 15.0) - raHours
        while (eqTime > 12.0) eqTime -= 24.0
        while (eqTime < -12.0) eqTime += 24.0

        return SolarPosition(
            declinationRad = declRad,
            equationOfTimeHours = eqTime,
        )
    }

    private fun julianDay0hUtc(date: LocalDate): Double {
        var y = date.year
        var m = date.monthValue
        val d = date.dayOfMonth
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun normalizeDegrees(deg: Double): Double {
        val res = deg % 360.0
        return if (res < 0) res + 360.0 else res
    }

    private fun normalizeHours(hours: Double): Double {
        val res = hours % 24.0
        return if (res < 0) res + 24.0 else res
    }
}
