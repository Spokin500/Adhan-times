package com.example.adhan.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.LocationSource
import com.example.adhan.domain.model.ThemeMode
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.util.Locale

val Context.adhanPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "adhan_user_preferences",
)

object LanguageResolver {
    fun resolveLocale(
        preference: AppLanguage,
        systemLocale: Locale = Locale.getDefault(),
    ): Locale {
        return when (preference) {
            AppLanguage.TR -> Locale.forLanguageTag("tr")
            AppLanguage.EN -> Locale.forLanguageTag("en")
            AppLanguage.SYSTEM -> {
                when (systemLocale.language.lowercase(Locale.ROOT)) {
                    "tr" -> Locale.forLanguageTag("tr")
                    "en" -> Locale.forLanguageTag("en")
                    // Rule: Unsupported device languages default to Turkish
                    else -> Locale.forLanguageTag("tr")
                }
            }
        }
    }
}

class DataStoreSettingsRepository(
    private val dataStore: DataStore<Preferences>,
) : SettingsRepository {

    private object Keys {
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ENABLE_ADHAN_AUDIO = booleanPreferencesKey("enable_adhan_audio")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val ASR_MADHHAB = stringPreferencesKey("asr_madhhab")
        val STAGE2_DELAY_MIN = intPreferencesKey("stage2_delay_minutes")
        val STAGE3_DELAY_MIN = intPreferencesKey("stage3_delay_minutes")
        val LOC_LAT = doublePreferencesKey("location_latitude")
        val LOC_LON = doublePreferencesKey("location_longitude")
        val LOC_CITY = stringPreferencesKey("location_city")
        val LOC_DISTRICT = stringPreferencesKey("location_district")
        val LOC_SOURCE = stringPreferencesKey("location_source")
        val LOC_UPDATED_AT = longPreferencesKey("location_updated_at")
    }

    override val preferencesFlow: Flow<UserPreferences> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs -> mapPreferences(prefs) }

    override suspend fun getCurrentPreferences(): UserPreferences = preferencesFlow.first()

    override suspend fun setLanguage(language: AppLanguage) {
        dataStore.edit { it[Keys.APP_LANGUAGE] = language.tag }
    }

    override suspend fun setThemeMode(themeMode: ThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = themeMode.key }
    }

    override suspend fun setEnableAdhanAudio(enabled: Boolean) {
        dataStore.edit { it[Keys.ENABLE_ADHAN_AUDIO] = enabled }
    }

    override suspend fun setNotificationsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    override suspend fun setAsrMadhhab(madhhab: AsrMadhhab) {
        dataStore.edit { it[Keys.ASR_MADHHAB] = madhhab.name }
    }

    override suspend fun setStageDelays(stage2Minutes: Int, stage3Minutes: Int) {
        val safeStage2 = stage2Minutes.coerceIn(1, 10)
        val safeStage3 = stage3Minutes.coerceIn(safeStage2 + 1, 20)
        dataStore.edit {
            it[Keys.STAGE2_DELAY_MIN] = safeStage2
            it[Keys.STAGE3_DELAY_MIN] = safeStage3
        }
    }

    override suspend fun saveLocation(location: LocationInfo) {
        dataStore.edit {
            it[Keys.LOC_LAT] = location.latitude
            it[Keys.LOC_LON] = location.longitude
            it[Keys.LOC_CITY] = location.city
            it[Keys.LOC_DISTRICT] = location.district
            it[Keys.LOC_SOURCE] = location.source.name
            it[Keys.LOC_UPDATED_AT] = location.updatedAtEpochMs
        }
    }

    private fun mapPreferences(prefs: Preferences): UserPreferences {
        val lat = prefs[Keys.LOC_LAT]
        val lon = prefs[Keys.LOC_LON]
        val city = prefs[Keys.LOC_CITY]
        val district = prefs[Keys.LOC_DISTRICT].orEmpty()
        val sourceStr = prefs[Keys.LOC_SOURCE]
        val updatedAt = prefs[Keys.LOC_UPDATED_AT] ?: 0L

        val savedLocation = if (lat != null && lon != null && !city.isNullOrBlank()) {
            val source = runCatching {
                LocationSource.valueOf(sourceStr ?: LocationSource.DEFAULT.name)
            }.getOrDefault(LocationSource.DEFAULT)
            LocationInfo(
                latitude = lat,
                longitude = lon,
                city = city,
                district = district,
                source = source,
                updatedAtEpochMs = updatedAt,
            )
        } else {
            null
        }

        val madhhab = runCatching {
            AsrMadhhab.valueOf(prefs[Keys.ASR_MADHHAB] ?: AsrMadhhab.STANDARD.name)
        }.getOrDefault(AsrMadhhab.STANDARD)

        val stage2 = (prefs[Keys.STAGE2_DELAY_MIN] ?: 2).coerceIn(1, 10)
        val stage3 = (prefs[Keys.STAGE3_DELAY_MIN] ?: 5).coerceIn(stage2 + 1, 20)

        return UserPreferences(
            appLanguage = AppLanguage.fromTag(prefs[Keys.APP_LANGUAGE]),
            themeMode = ThemeMode.fromKey(prefs[Keys.THEME_MODE]),
            enableAdhanAudio = prefs[Keys.ENABLE_ADHAN_AUDIO] ?: false,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            asrMadhhab = madhhab,
            stage2DelayMinutes = stage2,
            stage3DelayMinutes = stage3,
            savedLocation = savedLocation,
        )
    }
}

/**
 * Synchronous idempotency guard for BroadcastReceivers so duplicate alarms for the exact same
 * (date, prayer, stage) cannot trigger multiple notifications or audio streams.
 */
class AlarmDeliveryGuard(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("adhan_alarm_delivery_guard", Context.MODE_PRIVATE)

    @Synchronized
    fun markAndCheckShouldDeliver(eventKey: String): Boolean {
        if (prefs.contains(eventKey)) {
            return false
        }
        // Keep store bounded to recent entries
        if (prefs.all.size > 150) {
            prefs.edit().clear().apply()
        }
        prefs.edit().putLong(eventKey, System.currentTimeMillis()).commit()
        return true
    }

    @Synchronized
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
