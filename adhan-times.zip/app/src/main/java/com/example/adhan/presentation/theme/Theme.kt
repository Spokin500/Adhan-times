package com.example.adhan.presentation.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.adhan.domain.model.ThemeMode

@Immutable
data class AdhanAccentColors(
    val heroGradientStart: Color,
    val heroGradientEnd: Color,
    val heroOnSurface: Color,
    val goldAccent: Color,
    val goldSoftContainer: Color,
    val passedText: Color,
)

val LocalAdhanAccentColors = staticCompositionLocalOf {
    AdhanAccentColors(
        heroGradientStart = EmeraldDeep,
        heroGradientEnd = EmeraldPrimary,
        heroOnSurface = Color.White,
        goldAccent = GoldBright,
        goldSoftContainer = GoldContainer,
        passedText = InkMuted,
    )
}

private val AdhanLightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = GoldAccent,
    onSecondary = Color.White,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = OnGoldContainer,
    background = IvorySurface,
    onBackground = InkPrimary,
    surface = IvorySurface,
    onSurface = InkPrimary,
    surfaceVariant = IvorySurfaceVariant,
    onSurfaceVariant = InkMuted,
)

private val AdhanDarkColorScheme = darkColorScheme(
    primary = NightEmeraldPrimary,
    onPrimary = NightOnPrimary,
    primaryContainer = NightEmeraldContainer,
    onPrimaryContainer = NightOnContainer,
    secondary = GoldBright,
    onSecondary = OnGoldContainer,
    secondaryContainer = Color(0xFF3E2D0B),
    onSecondaryContainer = GoldContainer,
    background = NightEmeraldBg,
    onBackground = NightTextPrimary,
    surface = NightEmeraldSurface,
    onSurface = NightTextPrimary,
    surfaceVariant = NightEmeraldCard,
    onSurfaceVariant = NightTextMuted,
)

private val AdhanShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun AdhanTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        isDark -> AdhanDarkColorScheme
        else -> AdhanLightColorScheme
    }

    val accentColors = if (isDark) {
        AdhanAccentColors(
            heroGradientStart = Color(0xFF061E18),
            heroGradientEnd = Color(0xFF124236),
            heroOnSurface = NightTextPrimary,
            goldAccent = GoldBright,
            goldSoftContainer = Color(0xFF3A2A0A),
            passedText = NightTextMuted,
        )
    } else {
        AdhanAccentColors(
            heroGradientStart = EmeraldDeep,
            heroGradientEnd = Color(0xFF155C4C),
            heroOnSurface = Color(0xFFFAF7F0),
            goldAccent = GoldBright,
            goldSoftContainer = GoldContainer,
            passedText = InkMuted,
        )
    }

    CompositionLocalProvider(LocalAdhanAccentColors provides accentColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AdhanTypography,
            shapes = AdhanShapes,
            content = content,
        )
    }
}
