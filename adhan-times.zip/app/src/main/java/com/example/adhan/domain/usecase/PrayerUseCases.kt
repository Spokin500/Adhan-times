package com.example.adhan.domain.usecase

import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.model.NextPrayerState
import com.example.adhan.domain.repository.PrayerTimesRepository
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class GetDailyPrayerTimesUseCase(
    private val prayerTimesRepository: PrayerTimesRepository,
) {
    operator fun invoke(
        date: LocalDate,
        location: LocationInfo,
        zoneId: ZoneId,
        asrMadhhab: AsrMadhhab,
    ): DailyPrayerTimes = prayerTimesRepository.getPrayerTimes(date, location, zoneId, asrMadhhab)
}

/**
 * Computes the next upcoming prayer and remaining countdown using pre-calculated
 * today and tomorrow schedules without re-running astronomical calculations every second.
 */
class ComputeNextPrayerUseCase {
    operator fun invoke(
        now: Instant,
        todayTimes: DailyPrayerTimes,
        tomorrowTimes: DailyPrayerTimes,
    ): NextPrayerState {
        val todayEntries = todayTimes.entries
        val nextTodayIndex = todayEntries.indexOfFirst { it.instant.isAfter(now) }

        return if (nextTodayIndex >= 0) {
            val next = todayEntries[nextTodayIndex]
            val previous = if (nextTodayIndex > 0) todayEntries[nextTodayIndex - 1] else null
            val remainingMillis = Duration.between(now, next.instant).toMillis().coerceAtLeast(0L)
            val totalMillis = if (previous != null) {
                Duration.between(previous.instant, next.instant).toMillis().coerceAtLeast(1L)
            } else {
                // Before Fajr: measure against approximate start of civil day
                Duration.between(
                    todayTimes.date.atStartOfDay(todayTimes.zoneId).toInstant(),
                    next.instant,
                ).toMillis().coerceAtLeast(1L)
            }
            val elapsedMillis = (totalMillis - remainingMillis).coerceIn(0L, totalMillis)
            NextPrayerState(
                nextPrayer = next,
                previousPrayer = previous,
                remainingMillis = remainingMillis,
                progressFraction = (elapsedMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f),
                isTomorrow = false,
            )
        } else {
            // All today's prayers have passed; target tomorrow's Imsak (Fajr)
            val tomorrowImsak = tomorrowTimes.entries.first()
            val todayIsha = todayEntries.last()
            val remainingMillis = Duration.between(now, tomorrowImsak.instant).toMillis().coerceAtLeast(0L)
            val totalMillis = Duration.between(todayIsha.instant, tomorrowImsak.instant).toMillis().coerceAtLeast(1L)
            val elapsedMillis = (totalMillis - remainingMillis).coerceIn(0L, totalMillis)
            NextPrayerState(
                nextPrayer = tomorrowImsak,
                previousPrayer = todayIsha,
                remainingMillis = remainingMillis,
                progressFraction = (elapsedMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f),
                isTomorrow = true,
            )
        }
    }
}
