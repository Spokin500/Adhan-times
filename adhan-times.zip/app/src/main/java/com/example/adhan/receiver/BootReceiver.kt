package com.example.adhan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.adhan.AdhanApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }

        val app = context.applicationContext as? AdhanApplication ?: return
        val pendingResult: PendingResult? = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                app.appContainer.alarmScheduler.rescheduleAll()
            } finally {
                pendingResult?.finish()
            }
        }
    }
}
