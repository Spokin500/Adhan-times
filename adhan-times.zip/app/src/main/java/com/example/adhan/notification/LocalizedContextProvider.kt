package com.example.adhan.notification

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import com.example.R
import com.example.adhan.data.local.LanguageResolver
import com.example.adhan.domain.model.AppLanguage
import com.example.adhan.domain.model.PrayerName
import java.util.Locale

object LocalizedContextProvider {

    fun localizedContext(
        baseContext: Context,
        language: AppLanguage,
        systemLocale: Locale = Locale.getDefault(),
    ): Context {
        val targetLocale = LanguageResolver.resolveLocale(language, systemLocale)
        val config = Configuration(baseContext.resources.configuration)
        config.setLocale(targetLocale)
        return baseContext.createConfigurationContext(config)
    }

    @StringRes
    fun prayerNameRes(prayer: PrayerName): Int = when (prayer) {
        PrayerName.IMSAK -> R.string.prayer_imsak
        PrayerName.SUNRISE -> R.string.prayer_sunrise
        PrayerName.DHUHR -> R.string.prayer_dhuhr
        PrayerName.ASR -> R.string.prayer_asr
        PrayerName.MAGHRIB -> R.string.prayer_maghrib
        PrayerName.ISHA -> R.string.prayer_isha
    }
}
