package com.example.adhan.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.adhan.domain.model.PrayerName
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AdhanPlaybackController {
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _activePrayer = MutableStateFlow<PrayerName?>(null)
    val activePrayer: StateFlow<PrayerName?> = _activePrayer.asStateFlow()

    internal fun updatePlaybackState(playing: Boolean, prayer: PrayerName? = null) {
        _isPlaying.value = playing
        _activePrayer.value = if (playing) prayer else null
    }

    fun startAdhan(context: Context, prayer: PrayerName) {
        val intent = Intent(context, AdhanAudioService::class.java).apply {
            action = AdhanAudioService.ACTION_PLAY_ADHAN
            putExtra(AdhanAudioService.EXTRA_PRAYER_INDEX, prayer.index)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun stopAdhan(context: Context) {
        updatePlaybackState(playing = false, prayer = null)
        val intent = Intent(context, AdhanAudioService::class.java).apply {
            action = AdhanAudioService.ACTION_STOP_ADHAN
        }
        runCatching {
            context.startService(intent)
        }
    }
}
