package com.example.adhan.presentation.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.adhan.presentation.home.HomeScreen
import com.example.adhan.presentation.home.HomeViewModel
import com.example.adhan.presentation.location.LocationScreen
import com.example.adhan.presentation.location.LocationViewModel
import com.example.adhan.presentation.settings.SettingsScreen
import com.example.adhan.presentation.settings.SettingsViewModel
import kotlinx.serialization.Serializable

@Serializable
data object HomeRoute

@Serializable
data object LocationRoute

@Serializable
data object SettingsRoute

private data class NavDestinationItem(
    val route: Any,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
    val matchesRoute: (androidx.navigation.NavDestination?) -> Boolean,
)

@Composable
fun AdhanAppScaffold(
    homeViewModel: HomeViewModel,
    locationViewModel: LocationViewModel,
    settingsViewModel: SettingsViewModel,
    modifier: Modifier = Modifier,
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val destinations = listOf(
        NavDestinationItem(
            route = HomeRoute,
            labelRes = R.string.nav_home,
            selectedIcon = Icons.Rounded.Schedule,
            unselectedIcon = Icons.Outlined.Schedule,
            testTag = "nav_home",
            matchesRoute = { it?.hasRoute<HomeRoute>() == true },
        ),
        NavDestinationItem(
            route = LocationRoute,
            labelRes = R.string.nav_location,
            selectedIcon = Icons.Rounded.LocationOn,
            unselectedIcon = Icons.Outlined.LocationOn,
            testTag = "nav_location",
            matchesRoute = { it?.hasRoute<LocationRoute>() == true },
        ),
        NavDestinationItem(
            route = SettingsRoute,
            labelRes = R.string.nav_settings,
            selectedIcon = Icons.Rounded.Settings,
            unselectedIcon = Icons.Outlined.Settings,
            testTag = "nav_settings",
            matchesRoute = { it?.hasRoute<SettingsRoute>() == true },
        ),
    )

    val navigateSingleTop: (Any) -> Unit = { targetRoute ->
        navController.navigate(targetRoute) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                    ) {
                        destinations.forEach { item ->
                            val selected = item.matchesRoute(currentDestination)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes),
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.testTag),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useRail) {
                    NavigationRail {
                        destinations.forEach { item ->
                            val selected = item.matchesRoute(currentDestination)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes),
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.testTag),
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = HomeRoute,
                    modifier = Modifier.weight(1f),
                ) {
                    composable<HomeRoute> {
                        val uiState by homeViewModel.uiState.collectAsStateWithLifecycle()
                        HomeScreen(
                            uiState = uiState,
                            onRefreshLocation = homeViewModel::refreshGpsLocation,
                            onNavigateToLocation = { navigateSingleTop(LocationRoute) },
                            onStopAdhan = homeViewModel::stopAdhanAudio,
                            onPermissionsUpdated = homeViewModel::refreshPermissionsSnapshot,
                            onDismissStatusMessage = homeViewModel::dismissStatusMessage,
                        )
                    }

                    composable<LocationRoute> {
                        val uiState by locationViewModel.uiState.collectAsStateWithLifecycle()
                        LocationScreen(
                            uiState = uiState,
                            onSearchQueryChanged = locationViewModel::onSearchQueryChanged,
                            onCityClicked = locationViewModel::onCityClicked,
                            onDistrictSelected = locationViewModel::onDistrictSelected,
                            onDetectGps = locationViewModel::detectGpsLocation,
                            onPermissionResult = locationViewModel::onPermissionResult,
                            onClearFeedback = locationViewModel::clearFeedback,
                        )
                    }

                    composable<SettingsRoute> {
                        val uiState by settingsViewModel.uiState.collectAsStateWithLifecycle()
                        SettingsScreen(
                            uiState = uiState,
                            onLanguageChange = settingsViewModel::setLanguage,
                            onThemeChange = settingsViewModel::setThemeMode,
                            onAdhanAudioToggle = settingsViewModel::setEnableAdhanAudio,
                            onNotificationsToggle = settingsViewModel::setNotificationsEnabled,
                            onStageDelaysChange = settingsViewModel::setStageDelays,
                            onAsrMadhhabChange = settingsViewModel::setAsrMadhhab,
                            onSendTestNotification = settingsViewModel::sendTestNotification,
                            onRefreshLocation = settingsViewModel::refreshLocation,
                            onNavigateToLocation = { navigateSingleTop(LocationRoute) },
                            onStopAdhan = settingsViewModel::stopAdhanAudio,
                            onPermissionsUpdated = settingsViewModel::refreshPermissions,
                            onClearSnackbar = settingsViewModel::clearSnackbar,
                        )
                    }
                }
            }
        }
    }
}
