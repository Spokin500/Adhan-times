package com.example.adhan.data.prayer

import com.example.adhan.domain.calculation.PrayerCalculationEngine
import com.example.adhan.domain.model.AsrMadhhab
import com.example.adhan.domain.model.CalculationParameters
import com.example.adhan.domain.model.DailyPrayerTimes
import com.example.adhan.domain.model.LocationInfo
import com.example.adhan.domain.repository.PrayerTimesRepository
import java.time.LocalDate
import java.time.ZoneId

class PrayerTimesRepositoryImpl(
    private val calculationEngine: PrayerCalculationEngine,
) : PrayerTimesRepository {

    override fun getPrayerTimes(
        date: LocalDate,
        location: LocationInfo,
        zoneId: ZoneId,
        asrMadhhab: AsrMadhhab,
    ): DailyPrayerTimes {
        val parameters = CalculationParameters(asrMadhhab = asrMadhhab)
        return calculationEngine.calculate(
            date = date,
            location = location,
            zoneId = zoneId,
            parameters = parameters,
        )
    }
}
