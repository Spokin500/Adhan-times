package com.example.adhan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.adhan.AdhanApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TimeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_TIME_CHANGED &&
            action != Intent.ACTION_TIMEZONE_CHANGED &&
            action != Intent.ACTION_DATE_CHANGED
        ) {
            return
        }

        val app = context.applicationContext as? AdhanApplication ?: return
        val pendingResult: PendingResult? = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                app.appContainer.alarmDeliveryGuard.clearAll()
                app.appContainer.alarmScheduler.rescheduleAll()
            } finally {
                pendingResult?.finish()
            }
        }
    }
}
