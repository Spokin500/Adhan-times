package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.adhan.AdhanApplication
import com.example.adhan.domain.model.UserPreferences
import com.example.adhan.notification.LocalizedContextProvider
import com.example.adhan.presentation.home.HomeViewModel
import com.example.adhan.presentation.location.LocationViewModel
import com.example.adhan.presentation.navigation.AdhanAppScaffold
import com.example.adhan.presentation.settings.SettingsViewModel
import com.example.adhan.presentation.theme.AdhanTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as AdhanApplication).appContainer

        setContent {
            val preferences by appContainer.settingsRepository.preferencesFlow
                .collectAsStateWithLifecycle(initialValue = UserPreferences())

            val baseContext = LocalContext.current
            val localizedContext = remember(baseContext, preferences.appLanguage) {
                LocalizedContextProvider.localizedContext(baseContext, preferences.appLanguage)
            }

            val homeViewModel: HomeViewModel = viewModel(factory = appContainer.viewModelFactory)
            val locationViewModel: LocationViewModel = viewModel(factory = appContainer.viewModelFactory)
            val settingsViewModel: SettingsViewModel = viewModel(factory = appContainer.viewModelFactory)

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        homeViewModel.onAppResumed()
                        settingsViewModel.refreshPermissions()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalActivityResultRegistryOwner provides this@MainActivity,
            ) {
                AdhanTheme(themeMode = preferences.themeMode) {
                    AdhanAppScaffold(
                        homeViewModel = homeViewModel,
                        locationViewModel = locationViewModel,
                        settingsViewModel = settingsViewModel,
                    )
                }
            }
        }
    }
}
